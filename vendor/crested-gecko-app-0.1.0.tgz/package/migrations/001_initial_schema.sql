-- 001_initial_schema.sql
--
-- Initial Postgres / Supabase schema for the crested-gecko-app genetics
-- backend. Implements the data model described in
-- reference/app-data-model.md:
--   * traits (trait database, public-read)
--   * animals (owner-scoped, with JSONB genotype)
--   * clutches (breeding records header)
--   * pairings (sire × dam pairing records)
--   * row-level security policies (Supabase-compatible)
--
-- The 'users' table is assumed to come from Supabase auth
-- (auth.users). Owner foreign keys reference auth.users(id).

BEGIN;

-- -----------------------------------------------------------------------
-- Extensions
-- -----------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- -----------------------------------------------------------------------
-- updated_at helper
-- -----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- -----------------------------------------------------------------------
-- traits (public-read)
-- -----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS traits (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  alternate_names TEXT[] DEFAULT '{}'::TEXT[],
  category        TEXT NOT NULL CHECK (category IN (
    'base_color',
    'pattern_structure',
    'pattern_color',
    'modifier',
    'structural',
    'independent_trait'
  )),

  dominance       TEXT NOT NULL CHECK (dominance IN (
    'fixed_dominant',
    'dominant',
    'incomplete_dominant',
    'recessive',
    'codominant',
    'polygenic',
    'unconfirmed'
  )),
  locus                  TEXT NOT NULL,
  allele_notation        TEXT,
  super_allele_notation  TEXT,

  has_super_form         BOOLEAN NOT NULL DEFAULT FALSE,
  super_form_name        TEXT,
  super_health_risk      TEXT NOT NULL DEFAULT 'none' CHECK (super_health_risk IN (
    'none',
    'moderate',
    'severe',
    'lethal',
    'unknown'
  )),
  super_risk_notes       TEXT,

  description            TEXT NOT NULL,
  identification_markers TEXT[] NOT NULL DEFAULT '{}'::TEXT[],
  het_markers            TEXT[],

  originator             TEXT,
  first_produced_year    INTEGER,
  proven_by              TEXT,
  proven_year            INTEGER,

  allelic_with           TEXT[],
  epistatic_requirements TEXT[],
  antagonisms            TEXT[],

  primary_sources        JSONB NOT NULL DEFAULT '[]'::JSONB,

  confirmed              BOOLEAN NOT NULL DEFAULT FALSE,
  last_reviewed          DATE NOT NULL,

  created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_traits_category ON traits(category);
CREATE INDEX IF NOT EXISTS idx_traits_locus    ON traits(locus);

DROP TRIGGER IF EXISTS traits_set_updated_at ON traits;
CREATE TRIGGER traits_set_updated_at
  BEFORE UPDATE ON traits
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------
-- animals (owner-scoped)
-- -----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS animals (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name           TEXT,
  species        TEXT NOT NULL DEFAULT 'correlophus_ciliatus',

  sire_id        UUID REFERENCES animals(id) ON DELETE SET NULL,
  dam_id         UUID REFERENCES animals(id) ON DELETE SET NULL,

  -- Format: { "LOCUS_ID": ["allele1", "allele2"], ... }
  genotype       JSONB NOT NULL DEFAULT '{}'::JSONB,

  sex            TEXT CHECK (sex IN ('male', 'female', 'unknown')),
  hatched_date   DATE,
  weight_grams   NUMERIC(5,2),
  last_weighed   DATE,
  status         TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'sold', 'deceased', 'loaned')),
  notes          TEXT,

  acquired_from  TEXT,
  acquired_date  DATE,
  acquired_price NUMERIC(10,2),
  asking_price   NUMERIC(10,2),

  is_breeder     BOOLEAN NOT NULL DEFAULT FALSE,
  clutch_count   INTEGER,

  owner_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_animals_owner    ON animals(owner_id);
CREATE INDEX IF NOT EXISTS idx_animals_sire     ON animals(sire_id);
CREATE INDEX IF NOT EXISTS idx_animals_dam      ON animals(dam_id);
CREATE INDEX IF NOT EXISTS idx_animals_status   ON animals(status);
CREATE INDEX IF NOT EXISTS idx_animals_genotype ON animals USING GIN (genotype);

DROP TRIGGER IF EXISTS animals_set_updated_at ON animals;
CREATE TRIGGER animals_set_updated_at
  BEFORE UPDATE ON animals
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------
-- pairings (owner-scoped sire × dam records)
-- -----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pairings (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sire_id    UUID NOT NULL REFERENCES animals(id) ON DELETE CASCADE,
  dam_id     UUID NOT NULL REFERENCES animals(id) ON DELETE CASCADE,
  started_on DATE,
  ended_on   DATE,
  notes      TEXT,

  -- Cached prediction payload — refresh on demand.
  prediction JSONB,

  owner_id   UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CHECK (sire_id <> dam_id)
);

CREATE INDEX IF NOT EXISTS idx_pairings_owner ON pairings(owner_id);
CREATE INDEX IF NOT EXISTS idx_pairings_sire  ON pairings(sire_id);
CREATE INDEX IF NOT EXISTS idx_pairings_dam   ON pairings(dam_id);

DROP TRIGGER IF EXISTS pairings_set_updated_at ON pairings;
CREATE TRIGGER pairings_set_updated_at
  BEFORE UPDATE ON pairings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------
-- clutches (individual egg clutches within a pairing)
-- -----------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clutches (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pairing_id     UUID NOT NULL REFERENCES pairings(id) ON DELETE CASCADE,
  laid_on        DATE NOT NULL,
  incubation_temp_f NUMERIC(4,1),
  egg_count      INTEGER NOT NULL DEFAULT 2 CHECK (egg_count >= 0),
  hatched_count  INTEGER NOT NULL DEFAULT 0 CHECK (hatched_count >= 0),
  notes          TEXT,

  owner_id       UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_clutches_pairing ON clutches(pairing_id);
CREATE INDEX IF NOT EXISTS idx_clutches_owner   ON clutches(owner_id);

DROP TRIGGER IF EXISTS clutches_set_updated_at ON clutches;
CREATE TRIGGER clutches_set_updated_at
  BEFORE UPDATE ON clutches
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------
-- Row-level security
-- -----------------------------------------------------------------------
ALTER TABLE traits    ENABLE ROW LEVEL SECURITY;
ALTER TABLE animals   ENABLE ROW LEVEL SECURITY;
ALTER TABLE pairings  ENABLE ROW LEVEL SECURITY;
ALTER TABLE clutches  ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Traits are publicly readable" ON traits;
CREATE POLICY "Traits are publicly readable"
  ON traits FOR SELECT
  USING (TRUE);

DROP POLICY IF EXISTS "Users can only see their own animals" ON animals;
CREATE POLICY "Users can only see their own animals"
  ON animals FOR SELECT
  USING (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Users can only modify their own animals" ON animals;
CREATE POLICY "Users can only modify their own animals"
  ON animals FOR ALL
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Users can only see their own pairings" ON pairings;
CREATE POLICY "Users can only see their own pairings"
  ON pairings FOR SELECT
  USING (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Users can only modify their own pairings" ON pairings;
CREATE POLICY "Users can only modify their own pairings"
  ON pairings FOR ALL
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Users can only see their own clutches" ON clutches;
CREATE POLICY "Users can only see their own clutches"
  ON clutches FOR SELECT
  USING (auth.uid() = owner_id);

DROP POLICY IF EXISTS "Users can only modify their own clutches" ON clutches;
CREATE POLICY "Users can only modify their own clutches"
  ON clutches FOR ALL
  USING (auth.uid() = owner_id)
  WITH CHECK (auth.uid() = owner_id);

COMMIT;
