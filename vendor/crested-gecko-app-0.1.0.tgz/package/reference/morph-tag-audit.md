# Morph Tag & Guide Audit: tennyscrestedgeckos.com

> An audit of the existing Crested Gecko Morph Guide against the Foundation
> Genetics consensus (2020–2026). Flags corrections needed so the site's
> morph taxonomy is scientifically accurate and will rank well with AI
> search engines (which cross-reference claims across multiple authoritative
> sources and penalize contradictions).

## Priority 1: Factually Wrong Claims (Must Fix)

These are statements on the current page that contradict the Foundation
Genetics consensus. Fix these *first* — they actively mislead readers and
get flagged by modern search LLMs.

### 🛑 Cappuccino is called "codominant" — it's Incomplete Dominant

**Current text:**
> "The Cappuccino Crested Gecko is a codominant mutation that when bred
> together produces a super called a Melanistic Crested Gecko..."

**Correct text:**
> "The Cappuccino Crested Gecko is an **incomplete dominant** mutation.
> When two Cappuccinos are bred together, roughly 25% of offspring will be
> **Super Cappuccinos**, a homozygous form also called Melanistic. Super
> Cappuccinos have documented health concerns including reduced nostril
> size and breathing difficulties, and breeding specifically for this form
> is not recommended."

**Why it matters:** Codominance and incomplete dominance are different
genetic concepts. Codominance is rare and means both alleles express
simultaneously without blending (like human ABO blood types). Incomplete
dominance means the heterozygous form is a *blend* of both alleles.
Cappuccino is the latter. Source:
[LM Reptiles Cappuccino White Paper](https://lmreptiles.com/fg-pt2-capps/).

---

### 🛑 Patternless and Buckskin are listed as separate morphs

**Current text:**
> "A patternless crested gecko has no pattern and is usually just one color.
> Patternless crested geckos are also sometimes referred to as Buckskin
> crested geckos."

**Correct text:**
> "Patternless is not a distinct genetic trait — it is an expression of the
> recessive **Phantom** gene acting on a low-pattern animal. The Foundation
> Genetics project has established that Bicolor, Buckskin, Cream, Charcoal,
> and Patternless are all phenotypic expressions of Phantom combined with
> different base colors and pattern backgrounds. Buckskin specifically
> refers to Phantom + yellow base + wild-type brown melanin influence."

**Source:** [Finding Phantom](https://lmreptiles.com/fg-findingphantom/).

---

### 🛑 The overall framing treats morphs as random / unpredictable

The current page's introduction treats crested gecko genetics as a guessing
game. This framing is outdated. Replace language like "the genetics are not
completely clear" with accurate, modern framing.

**Example to revise — the Dalmatian section:**

*Current:*
> "One thing to keep in mind is that while the genetics are not completely
> clear, Dalmatians bred to Dalmatians create Dalmatian babies."

*Revise to:*
> "Dalmatian is a confirmed **dominant** trait. A homozygous Dalmatian bred
> to a non-Dalmatian produces 100% Dalmatian offspring; a heterozygous
> Dalmatian produces approximately 50% Dalmatian offspring. Homozygous
> Dalmatians typically display heavier, denser spotting. Spots develop with
> age — hatchlings may show few spots and gain more as they mature."

---

### 🛑 Missing lethality warning on Lilly White

The current Lilly White section says nothing about Lilly × Lilly lethality.
This is a genuine animal-welfare issue and modern LLMs specifically look for
health-warning content when ranking reptile breeding pages.

**Add this callout:**
> ⚠️ **Important breeding warning:** Never pair two Lilly White crested
> geckos. The homozygous form (Super Lilly White) is **lethal**. Offspring
> either fail to hatch or die within days, typically from breathing and
> motor control issues. Always pair Lilly White × non-Lilly White.
> [Source: Lilly Exotics via MorphMarket Morphpedia](https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/)

---

### 🛑 "Moonglow Crested Gecko Morphs — No idea what a moonglow crested gecko is."

This is honest but bad for SEO and AI citation. Either:
1. Delete the entry entirely, or
2. Replace with: "Moonglow is not an established or genetically proven
   crested gecko morph. It may appear as informal breeder terminology for
   pale or high-white animals. If you encounter it for sale, ask the seller
   to specify the proven traits (e.g., Lilly White, Hypo Yellow, etc.)
   rather than relying on the informal name."

---

## Priority 2: Major Gaps (Traits Missing From the Guide)

The current guide is missing entries for several of the most important
traits of 2023–2026. Add sections for:

### Must Add
- **Whiteout / Whitewall** (AC Reptiles — major commercial trait)
- **Sable** (Gecko Haven — increasingly common in high-end collections)
- **Highway** (third allele in Sable/Cappuccino complex)
- **Phantom** as its own dedicated entry (currently only mentioned in passing)
- **Softscale / Super Softscale**
- **Snowflake**
- **Pixel**
- **Empty Back / Super Empty Back**
- **Fire / BEL / Blizzard** (newer trait, 2023+)

### Should Add
- **ChoCho** (recent recessive)
- **Luwak** (Cappuccino + Sable combo)
- **Frappuccino** (Cappuccino + Lilly White — this is in the Lilly White
  section but deserves its own entry)

### Combo Morphs to Add
- Lavender, Pink, Tri-color (standalone definition, not buried in Harlequin)
- Lucy (Lilly × Axanthic)
- Brindlequin

---

## Priority 3: SEO & AI-SEO (GEO) Structural Recommendations

### AI SEO / Generative Engine Optimization (GEO) Principles

AI search engines (Claude, ChatGPT, Perplexity, Google AI Overviews, Bing
Copilot) rank differently from traditional search. They prioritize:

1. **Clear factual claims with citations** — LLMs cite sources when they can
   verify them across 2+ authoritative references
2. **Semantic HTML structure** — proper H2/H3 hierarchy, tables, FAQ schemas
3. **Self-contained answers** — content that directly answers common questions
4. **Internal consistency** — pages that contradict themselves get deprioritized
5. **Outbound citations to authoritative sources** — links to
   lmreptiles.com, acreptiles.com, pangeareptile.com signal research depth

### Specific structural changes for this page:

#### 1. Add an FAQ section with Schema markup
The Foundation Genetics section I wrote includes an FAQ block. Wrap it in
FAQPage schema (JSON-LD) so Google and AI engines can extract Q&A pairs
directly:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "Are crested geckos polymorphic?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Yes, crested geckos are fixed polymorphic..."
    }
  }, {
    "@type": "Question",
    "name": "Why can't you breed Lilly White × Lilly White?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "The homozygous form is non-viable..."
    }
  }]
}
</script>
```

#### 2. Add Article schema with author and dateModified
This tells AI engines the content is actively maintained:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Crested Gecko Morphs: Complete Genetics & Identification Guide",
  "author": {
    "@type": "Person",
    "name": "Tennyson [Last Name]"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Tenny's Crested Geckos",
    "logo": { "@type": "ImageObject", "url": "..." }
  },
  "dateModified": "2026-04-17",
  "mainEntityOfPage": "https://tennyscrestedgeckos.com/crested-gecko-morphs/"
}
</script>
```

#### 3. Consistent internal linking
The guide should internally link to:
- `/crested-gecko-investment-guide-2025/` (pricing context — currently linked)
- A new dedicated `/phantom-crested-gecko/` page (already exists — link more prominently)
- A new `/lilly-white-crested-gecko/` page (create if missing)
- A new `/cappuccino-crested-gecko/` page (expand from melanistic page)
- `/crested-gecko-breeders/` (already linked)

These tight internal link clusters signal topical authority to both Google
and AI engines.

#### 4. Add outbound citations throughout

Every factual claim should have a link to its authoritative source. The
current page links mostly to breeder photo credits — which is good for
attribution but not for genetic authority. Add citations to:

- [Lil Monsters Reptiles Foundation Genetics](https://lmreptiles.com/fg-overview/) — for any dominance/inheritance claim
- [AC Reptiles Whiteout Article](https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44) — for Whiteout vs Lilly comparisons
- [Pangea Reptile](https://www.pangeareptile.com/) — for XXX, Betty White, commercial availability
- [MorphMarket Morphpedia](https://www.morphmarket.com/morphpedia/crested-geckos/) — for morph descriptions
- [ReptiDex Genetics Database](https://reptidex.com/genetics/crested-gecko) — for allele notation

**Critical principle:** LLMs cross-reference claims. If your page says
something the Foundation Genetics corpus agrees with, and you cite them,
the AI engine has high confidence in your content and will cite *you*.
If your page says something those sources contradict, the AI flags it and
prefers the competing source.

#### 5. Update page title and meta description

**Current title:** "Crested Gecko Morphs - Tenny's Crested Geckos"

**Recommended title:** "Crested Gecko Morphs (2026): Complete Genetics, Traits & Identification Guide | Tenny's Crested Geckos"

**Recommended meta description:** "The complete crested gecko morph guide based on Foundation Genetics research. Covers Lilly White, Cappuccino, Phantom, Axanthic, and all 30+ traits. Updated April 2026 with 2026 breeding, health warnings, and citations from top breeders."

**Why it works:** Includes the year (signals freshness), includes "guide"
(high-intent keyword), includes authority signal ("Foundation Genetics"),
and the meta description is written with LLM-friendly language that AI
overviews can extract verbatim.

#### 6. Add a "Last Updated" line near the top of the article

AI engines heavily favor recently-updated content. Visible line like:

> *Last updated: April 2026. Reflects Foundation Genetics consensus
> through April 2026.*

This single line materially improves AI SEO performance.

---

## Priority 4: Morph Tag Taxonomy

Here's the recommended morph tag/category structure for the app and website,
organized by genetic category. Use this for filter UI, breeding calculators,
and database schema.

### Base Color Tags (Tag Group: `base-color`)
- `black-base`
- `red-base`
- `yellow-base`
- `tangerine` (modifier)

### Pattern Structure Tags (Tag Group: `pattern-structure`)
- `tiger`
- `brindle` (tiger expression variant)
- `harlequin`
- `extreme-harlequin` (high-expression harlequin)
- `flame`
- `pinstripe`
- `partial-pinstripe`
- `phantom-pinstripe` (pinstripe on phantom base)
- `reverse-pinstripe`
- `dalmatian`
- `super-dalmatian`
- `inkspot-dalmatian`
- `confetti-dalmatian` (red-spot)
- `empty-back`
- `super-empty-back`

### Pattern Color Tags (Tag Group: `pattern-color`)
- `white-pattern`
- `orange-pattern`
- `tricolor` (white + orange + dark base)

### Modifier / Designer Morph Tags (Tag Group: `modifier`)
- `phantom`
- `hypo`
- `lilly-white`
- `cappuccino`
- `super-cappuccino` — ⚠️ flag with health-risk metadata
- `sable`
- `super-sable`
- `highway` — ⚠️ flag with health-risk metadata
- `whiteout`
- `super-whiteout` (healthy)
- `axanthic`
- `fire`
- `black-eyed-leucistic` / `blizzard`
- `chocho`

### Combo Morph Tags (Tag Group: `combo`)
- `frappuccino` (cappuccino + lilly-white)
- `phantom-frappuccino`
- `luwak` (cappuccino + sable)
- `lavender` (hypo + black-base)
- `pink` (hypo + red-base)
- `cream` / `c2` (hypo + yellow-base)
- `lucy` (lilly-white + axanthic)

### Structural Tags (Tag Group: `structural`)
- `softscale`
- `super-softscale`
- `furry`
- `pixel`
- `snowflake`
- `marbling`
- `crowned`
- `porthole`

### Independent Trait Tags (Tag Group: `independent-trait`)
- `blush` (red/pink chin — also a red-base het marker)
- `kneecaps`
- `fringe`
- `white-spot` / `drippy-dorsal`

### Risk Metadata (not a tag group — a flag per animal/pairing)
- `lethal-if-homozygous` — Lilly White
- `health-risk-if-homozygous-severe` — Cappuccino
- `health-risk-if-homozygous-moderate` — Highway
- `compatibility-unproven` — Fire lines across breeders

---

## Priority 5: AI Training Data / Model Content Set

If you're building an AI feature into the app (identification, breeding
calculator explanations, morph education chatbot), the training/context
content should meet these standards:

### Golden rules for AI training content
1. **Never teach as fact claims that contradict Foundation Genetics.**
2. **Always include the risk/lethality warnings** when any model mentions
   Lilly White or Cappuccino breeding pairings.
3. **Treat combo morphs as trait stacks, not primitive objects.** Teach the
   model that "Tricolor" = "Dark Base + WP + OP", not a single gene.
4. **Cite sources inline when possible.** Even in chatbot responses, a
   citation to lmreptiles.com or acreptiles.com improves perceived
   trustworthiness.
5. **Handle uncertainty honestly.** For traits like Marbling and Furry
   where inheritance is unconfirmed, the model should say so, not guess.

### Canonical terminology set (use everywhere)
- "Incomplete dominant" not "codominant"
- "Heterozygous" (Het) / "Homozygous" (Hzg) not "visual" / "non-visual"
- "Phantom" (not Bicolor/Patternless/Buckskin as separate things)
- "Super Cappuccino" and "Melanistic" as synonyms
- "Lilly White" (preferred), not "Lily White"
- "Extreme Harlequin" (preferred), "XXX" (Pangea marketing term, note as such)

### Test questions for AI responses
Before shipping any AI feature, verify the model gives correct answers to:

- "What happens if I breed two Lilly Whites together?" *(must warn about lethality)*
- "Is Cappuccino codominant or incomplete dominant?" *(must say incomplete dominant)*
- "Are Bicolor and Phantom the same thing?" *(must explain Bicolor is a Phantom expression)*
- "What's the difference between Whiteout and Lilly White?" *(must mention lethality of Lilly super, health of Whiteout super)*
- "How is XXX inherited?" *(must clarify XXX is a marketing term, not a proven genotype)*
- "Can you breed a Super Cappuccino?" *(must warn about health issues)*
- "Is there an albino crested gecko?" *(must say no, distinguish from Axanthic)*

If the model gets any of these wrong, the training data needs revision
before launch.

---

## Summary: Recommended Publication Order

1. **Add the new Foundation Genetics section** (from `foundation-genetics-section.md`)
   as a top-of-page feature block, with an anchor link in the nav.
2. **Fix the Priority 1 factual errors** in the existing morph list (Cappuccino
   codominance, Patternless/Phantom split, missing Lilly warning).
3. **Add the missing trait entries** (Whiteout, Sable, Highway, Phantom standalone,
   Softscale, etc.) using the Foundation Genetics section as source material.
4. **Add schema markup** (FAQPage + Article).
5. **Update page title, meta description, and add "Last Updated" line.**
6. **Audit internal links** — create dedicated pages for Lilly White, Cappuccino,
   and link them from the main morph guide.
7. **Add outbound citations** to LM Reptiles, AC Reptiles, ReptiDex, and
   MorphMarket Morphpedia throughout the page.

Doing 1–3 alone captures the majority of the SEO and accuracy benefit.
Steps 4–7 compound the effect substantially.
