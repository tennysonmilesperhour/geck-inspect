# WordPress Edit Instructions: Crested Gecko Morphs Page

> **Target page:** https://tennyscrestedgeckos.com/crested-gecko-morphs/
>
> **Goal:** Fix factual errors and close content gaps without rewriting the
> entire page. Each edit below is formatted as a BEFORE / AFTER pair so you
> can locate the exact spot in the WordPress editor and swap the text.
>
> **Recommended order:** Do edits 1–6 first (Priority 1 corrections). Then
> add the new sections from edits 7–13. Then update page title and meta.

---

## Edit 1: Fix the Cappuccino "codominant" error

**Locate this heading:** `Cappuccino Crested Gecko Morphs`

### BEFORE
> The Cappuccino Crested Gecko is a codominant mutation that when bred
> together produces a super called a Melanistic Crested Gecko but recently
> US breeders have been referring to it as a Transparent crested gecko.
> The cappuccino crested gecko has a few traits that help make it
> identifiable. Namely the distinctive Y at the base of the tail, the white
> flecks or splotching along the lower end of the tail and spine, and the
> lack of lateral pattern. You can read more about the Cappuccino Crested
> Gecko Here.

### AFTER
> The Cappuccino Crested Gecko is an **incomplete dominant** mutation,
> discovered and proven by Reptile City Korea in 2020–2021. When two
> Cappuccinos are bred together, approximately 25% of offspring will be
> **Super Cappuccinos** (homozygous form), also called **Melanistic**.
>
> ⚠️ **Breeding note:** Super Cappuccinos have documented health concerns
> including reduced nostril size, breathing difficulties, and poor thriving.
> Breeding specifically to produce supers is not recommended. Source:
> <a href="https://lmreptiles.com/fg-pt2-capps/" target="_blank" rel="noopener">Lil
> Monsters Reptiles Cappuccino White Paper</a>.
>
> **How to identify a heterozygous Cappuccino:**
> <ol>
>   <li>Distinctive Y-shape at the base of the tail</li>
>   <li>White flecks or splotching along the lower spine and tail base</li>
>   <li>Reduced or absent lateral pattern</li>
>   <li>Bright, sharp white on the tail base in hatchlings, with a darker tail tip</li>
> </ol>
>
> You can read more about <a href="https://tennyscrestedgeckos.com/melanistic-crested-gecko/">Melanistic (Super Cappuccino) Crested Geckos here</a>.

---

## Edit 2: Fix the Patternless / Buckskin confusion

**Locate this heading:** `Patternless Crested Gecko Morphs`

### BEFORE
> A patternless crested gecko has no pattern and is usually just one color.
> Patternless crested geckos are also sometimes referred to as Buckskin
> crested geckos.

### AFTER
> Patternless crested geckos display little to no pattern with a solid or
> near-solid base color. Historically the hobby treated Patternless,
> Buckskin, Bicolor, Charcoal, and Cream as separate morphs — but the
> <a href="https://lmreptiles.com/fg-findingphantom/" target="_blank" rel="noopener">Foundation
> Genetics project</a> has established that all of these are phenotypic
> expressions of the recessive **Phantom** trait acting on different base
> color and pattern combinations.
>
> In other words, a Patternless is not a distinct gene — it is Phantom acting
> on a low-pattern animal. Buckskin is Phantom + yellow base + wild-type
> brown melanin. Charcoal is a dark Phantom. Bicolor is a Phantom with a
> distinct dorsal-vs-lateral color split.
>
> This means that to breed for any of these looks, you're really breeding
> for Phantom plus the appropriate base color and pattern background.

---

## Edit 3: Add the missing Lilly × Lilly lethality warning

**Locate this heading:** `Lilly White Crested Gecko Morphs`

### BEFORE
> Lilly white crested gecko is a genetic incomplete dominate gene that has
> a nice thick white dorsal stripe, stacked lateral scales near the belly.
> Sometimes they are also referred to as 'lily white crested geckos'. I'm
> unsure if 'Lilly' or 'Lily' is correct? Comment below.

### AFTER
> The Lilly White is an **incomplete dominant** genetic trait discovered by
> <a href="https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/" target="_blank" rel="noopener">Lilly
> Exotics (UK) in late 2010</a>. Hatchlings display a thick white dorsal
> stripe and stacked lateral scales near the belly, with the white
> coloration typically expanding as the animal matures.
>
> The trade spelling is "Lilly White" (named after the breeder, Lilly
> Exotics), though "Lily White" appears frequently online as an alternate
> spelling.
>
> ⚠️ **Critical breeding warning: Never pair Lilly White × Lilly White.**
> The homozygous form (Super Lilly White) is **lethal**. Offspring either
> fail to hatch or die within days of hatching due to extreme melanin
> reduction affecting breathing, motor control, and feeding. Standard
> breeding practice is Lilly White × non-Lilly White, which produces
> approximately 50% Lilly White and 50% non-Lilly White offspring.
>
> A practical alternative for breeders who want to stack white traits
> safely is <a href="https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44"
> target="_blank" rel="noopener">AC Reptiles' Whiteout gene</a>, which
> has a healthy and freely breedable homozygous form.

---

## Edit 4: Update the Dalmatian section to reflect confirmed inheritance

**Locate this heading:** `Dalmatian Crested Gecko Morphs`

### BEFORE
> The Dalmatian crested gecko comes in a variety of colors and patterns but
> all have black spots covering the body. Some Dalmatians have only a couple
> of spots while others have hundreds. Dalmatian crested geckos spots
> usually are black but Altitude Exotics has a 'confetti' line that has red
> and white spots, too. The large Dalmatian spots are called 'Ink Spots' or
> Ink Spot Dalmatian Crested Geckos. These spots are much larger and will
> cover the geckos body. One thing to keep in mind is that while the
> genetics are not completely clear, Dalmatians bred to Dalmatians create
> Dalmatian babies. But, the baby crested gecko may not have any or very
> few spots at birth. These spots start coming in as they get older and by
> about the 25 gram mark you should have a good idea of their full potential.

### AFTER
> The Dalmatian crested gecko displays black spots across the body, varying
> from a few spots to hundreds. Dalmatian is a confirmed **dominant** trait:
> a homozygous Dalmatian bred to a non-Dalmatian produces 100% Dalmatian
> offspring, while a heterozygous Dalmatian produces approximately 50%
> Dalmatian offspring. Homozygous Dalmatians typically display denser,
> heavier spotting. Source:
> <a href="https://lmreptiles.com/foundation-genetics/" target="_blank" rel="noopener">Foundation
> Genetics Part 1</a>.
>
> Spot variations include:
> <ul>
>   <li><strong>Standard black spots</strong> — the most common expression</li>
>   <li><strong>Ink Spot</strong> — exceptionally large spots that cover more of the body</li>
>   <li><strong>Super Dalmatian</strong> — 100+ spots (see dedicated section below)</li>
>   <li><strong>Confetti / Red Spot</strong> — red-colored spots pioneered by <a href="https://www.altitudeexotics.com/" target="_blank" rel="noopener">Altitude Exotics</a></li>
>   <li><strong>Phantom spots</strong> — spots that come and go with the gecko's fired-up vs fired-down state; often fade with age</li>
> </ul>
>
> Baby Dalmatians may hatch with few or no spots and develop their full
> spotting over time, typically reaching their adult spot count by around
> 25 grams.

---

## Edit 5: Rewrite the Phantom section (currently minimal)

**Locate this heading:** `Phantom Crested Gecko Morphs`

### BEFORE
> Phantom crested geckos have recently been proven to be a recessive trait
> and have become ever more popular to breed into many projects, including
> the Lilly White Phantoms and the Cappuccino Phantom projects. These solid
> colored crested geckos were misunderstood genetically up until a few
> years ago.
>
> Learn more about Phantom Crested Geckos here.

### AFTER
> Phantom is one of only two confirmed **simple recessive** traits in
> crested geckos (the other being Axanthic). Proven by the
> <a href="https://lmreptiles.com/fg-findingphantom/" target="_blank" rel="noopener">Foundation
> Genetics project</a>, Phantom adds melanin that darkens the xanthophore
> layer and suppresses pattern — especially along the dorsum.
>
> <strong>Critical insight:</strong> Many phenotypes historically treated
> as separate morphs are actually expressions of Phantom:
>
> <table>
>   <thead>
>     <tr><th>Phenotype</th><th>Actually Is</th></tr>
>   </thead>
>   <tbody>
>     <tr><td>Bicolor</td><td>Phantom with distinct dorsal vs lateral color</td></tr>
>     <tr><td>Patternless</td><td>Phantom on a low-pattern animal</td></tr>
>     <tr><td>Buckskin</td><td>Phantom + yellow base + wild-type brown melanin</td></tr>
>     <tr><td>Charcoal / OG Black</td><td>Dark Phantom with strong black base suppression</td></tr>
>     <tr><td>Cream (dorsal)</td><td>Phantom on yellow base with cream dorsal</td></tr>
>     <tr><td>Red Patternless</td><td>Phantom + red base</td></tr>
>   </tbody>
> </table>
>
> Phantom is widely used in combination projects, including Lilly White
> Phantoms, Cappuccino Phantoms, and Phantom Frappuccinos. Because it's
> recessive, an animal needs two copies (homozygous) to visibly express
> Phantom — heterozygous Phantoms look normal but can produce visual
> Phantom offspring when paired to other Phantom carriers.
>
> Phantom loses dominance near the base of the tail and on the laterals,
> which is why pinstripes and walling can still show through on Phantom
> animals.
>
> Learn more about <a href="https://tennyscrestedgeckos.com/phantom-crested-gecko/">Phantom
> Crested Geckos here</a>.

---

## Edit 6: Replace the "Moonglow" entry

**Locate this heading:** `Moonglow Crested Gecko Morphs`

### BEFORE
> The moonglow crested gecko is... a gecko that glows like the moon?
> No idea what a moonglow crested gecko is.

### AFTER
> "Moonglow" is not an established or genetically proven crested gecko
> morph. It occasionally appears as informal breeder terminology for
> pale, high-white, or very light-colored animals. If you see one listed
> for sale, ask the seller to specify the proven genetic traits present
> (Lilly White, Hypo Yellow, Phantom, Cream/C2, Whiteout, etc.) rather
> than relying on the informal name alone — this protects you from
> overpaying for what may simply be a high-expression combo with no
> unique genetic trait.

---

## Edit 7: Add a new section at the top of the page — the Foundation Genetics primer

**Where to insert:** Immediately after the first paragraph under "Crested
Gecko Morphs & Traits" (before the Albino section starts). This becomes
the authoritative primer that modern search engines and AI will heavily
favor.

```html
<h2>Crested Gecko Genetics: The Foundation Genetics Framework</h2>

<p><em>Last updated: April 2026. Reflects the current Foundation Genetics
consensus established by Lil Monsters Reptiles and Geckological, 2020–2026.</em></p>

<p>For roughly 20 years the crested gecko community described this species
as "polymorphic and genetically unpredictable." That framing is outdated.
Since around 2020, the <a href="https://lmreptiles.com/fg-overview/"
target="_blank" rel="noopener">Foundation Genetics project</a> — led by
Anthony &amp; Jessica Vasquez of Lil Monsters Reptiles and Tom Favazza of
Geckological, with contributions from Matt Parks (Pangea), Anthony Caponetto
(AC Reptiles), Allen Repashy, and others — has systematically proven
individual crested gecko traits through Mendelian breeding trials.</p>

<p>The result: most crested gecko traits now have confirmed dominance
classifications. The hobby is shifting from <em>lineage-based</em> breeding
(tracking parent names and looks) to <em>trait-based</em> breeding (tracking
specific genetic traits and their inheritance patterns).</p>

<h3>The Five Dominance Categories</h3>

<p>Every crested gecko trait falls into one of these categories:</p>

<ol>
  <li><strong>Fixed dominant (wild-type)</strong> — Present in every
  crested gecko; cannot be bred out. Example: <em>Tiger</em>.</li>

  <li><strong>Dominant</strong> — One copy looks identical to two copies.
  Examples: <em>Dalmatian, Pinstripe, Hypo</em>.</li>

  <li><strong>Incomplete dominant</strong> — One copy produces the visible
  trait; two copies produce a distinct "super" form. Examples:
  <em>Lilly White, Cappuccino, Sable, Whiteout, Empty Back, Softscale</em>.</li>

  <li><strong>Recessive</strong> — Requires two copies to be visible.
  Confirmed examples: <em>Phantom, Axanthic</em>. Suspected: <em>Red Base</em>.</li>

  <li><strong>Codominant</strong> — Extremely rare in any animal species.
  Most traits called "codominant" in the crested gecko hobby are actually
  incomplete dominant — an important correction.</li>
</ol>

<h3>Terminology: The Most Common Hobby Mistakes</h3>

<p>The single most misused term is "het." It does <strong>not</strong>
mean "recessive" or "non-visual." <strong>Heterozygous (het)</strong>
simply means the two alleles at a gene location are different from each
other. Dominant, incomplete dominant, and recessive traits can all be
het or homozygous. Source:
<a href="https://lmreptiles.com/foundation-genetics/" target="_blank"
rel="noopener">Foundation Genetics Part 1</a>.</p>

<h3>Morphs Are Layered Trait Stacks</h3>

<p>Most named morphs are not single genes — they are combinations of
individual traits stacked on the animal:</p>

<ol>
  <li><strong>Base color</strong> (Black, Red, Yellow, Tangerine-modified)</li>
  <li><strong>Pattern structure</strong> (Harlequin, Flame, Pinstripe,
      Tiger, Dalmatian)</li>
  <li><strong>Pattern color</strong> (White Pattern or Orange Pattern)</li>
  <li><strong>Modifiers</strong> (Phantom, Hypo, Cappuccino, Lilly White,
      Axanthic, Whiteout, Sable)</li>
  <li><strong>Structural</strong> (Softscale, Furry, crest traits)</li>
</ol>

<p>A "Tricolor Extreme Harlequin" is not one gene — it's Black Base +
Harlequin (high expression) + both White Pattern and Orange Pattern +
strong tigering. Five layered traits, not one.</p>

<h3>Critical Breeding Warnings</h3>

<p>Three alleles have documented homozygous risks that responsible breeders
must plan around:</p>

<ul>
  <li>🛑 <strong>Lilly White (L/L) is lethal.</strong> Never pair two
  Lilly Whites. Super Lilly White offspring fail to hatch or die shortly
  after hatching.</li>

  <li>⚠️ <strong>Super Cappuccino (CAPP/CAPP, "Melanistic") has severe
  health issues</strong> including breathing difficulty. Breeding
  specifically for supers is not recommended.</li>

  <li>⚠️ <strong>Super Highway has documented complications.</strong>
  Use caution in pairing.</li>
</ul>

<h3>Primary Sources</h3>

<p>For the full genetics framework, these are the authoritative sources:</p>

<ul>
  <li><a href="https://lmreptiles.com/fg-overview/" target="_blank"
      rel="noopener">LM Reptiles Foundation Genetics</a> (the consensus source)</li>
  <li><a href="https://acreptiles.com/" target="_blank"
      rel="noopener">AC Reptiles</a> (Whiteout, Harry, C2 lines)</li>
  <li><a href="https://www.pangeareptile.com/" target="_blank"
      rel="noopener">Pangea Reptile</a> (XXX, Betty White lines)</li>
  <li><a href="https://reptidex.com/genetics/crested-gecko" target="_blank"
      rel="noopener">ReptiDex Genetics Library</a> (organized allele database)</li>
  <li><a href="https://www.morphmarket.com/morphpedia/crested-geckos/"
      target="_blank" rel="noopener">MorphMarket Morphpedia</a> (trait reference)</li>
</ul>
```

---

## Edit 8: Add a new Whiteout section

**Where to insert:** After the existing Lilly White section.

```html
<h4>Whiteout / Whitewall Crested Gecko Morphs</h4>

<p>Whiteout (sometimes called Whitewall) is an incomplete dominant trait
developed by <a href="https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44"
target="_blank" rel="noopener">Anthony Caponetto of AC Reptiles</a>. It
creates cream or white coloration along the lateral edges of the body.</p>

<p>The strategic value of Whiteout is that — unlike Lilly White —
<strong>its homozygous form is healthy and freely breedable</strong>.
Homozygous Whiteout × homozygous Whiteout produces 100% homozygous Whiteout
offspring, with a much more extreme white expression than the heterozygous
form.</p>

<p>Breeders who want to develop a white-heavy collection often work with
both Whiteout and Lilly White for different reasons: Lilly produces more
dramatic whitening with age, while Whiteout allows safe super × super
breedings that Lilly × Lilly pairings cannot.</p>
```

---

## Edit 9: Add a new Sable section

**Where to insert:** After the new Whiteout section.

```html
<h4>Sable Crested Gecko Morphs</h4>

<p>Sable is an incomplete dominant trait originated by Gecko Haven from
their "Rialto" line. It produces darker, more saturated coloration —
typically shades of brown, black, or gray with fluffy white pattern.
Offspring often hatch with tricolor appearance and fade to black, gray,
brown, and white at maturity.</p>

<p>Sable is <strong>allelic with Cappuccino</strong> — meaning both traits
occupy the same gene locus. However, Sable × Cappuccino crosses do NOT
produce Super Cappuccino, confirming they are distinct alleles at the same
location. The compound heterozygote phenotype is called a
<strong>Luwak</strong>. Source:
<a href="https://reptidex.com/genetics/crested-gecko" target="_blank"
rel="noopener">ReptiDex</a>.</p>
```

---

## Edit 10: Add a new Axanthic section (expand current content)

**Locate this heading:** `Axanthic Crested Gecko Morphs`

### BEFORE
> The axanthic crested gecko is a black and white crested gecko that has
> been proven to be a simple recessive crested gecko morph. The axanthic
> gene removes all the color from the gecko. Multiple breeders are working
> with the Axanthic line, Altitude Exotics, A woman in Florida, Wild
> Things, and probably a few others. They have been sold for a few years
> so visual axanthics and 100% hets can be found being sold from the early
> adopters (buyers).

### AFTER
> The Axanthic is one of only two confirmed simple recessive traits in
> crested geckos (the other being Phantom). It was proven and made
> commercially available by <a href="https://www.altitudeexotics.com/"
> target="_blank" rel="noopener">Altitude Exotics</a>. Axanthic affects
> the xanthophore layer of the chromatophore, removing yellow and red
> pigment and producing black-and-white or grayscale animals.
>
> <strong>Important distinction:</strong> Axanthic is not the same as
> albino. A true albino lacks melanin (the black/brown pigment). No true
> albino crested gecko has been produced as of 2026. Axanthics still
> produce melanin normally; they simply lack the warm-tone pigments.
>
> Because Axanthic is recessive, you need two copies for the trait to be
> visible. Heterozygous Axanthics look normal. Visual Axanthic × visual
> Axanthic produces 100% visual Axanthic offspring. Visual × heterozygous
> produces approximately 50% visual Axanthic, 50% heterozygous. Altitude
> Exotics first combined Axanthic with Lilly White in 2019 to produce
> the <strong>Lucy</strong> morph.
>
> Multiple breeders now work with the Axanthic line. Hets and visual
> Axanthics are available from the original producers and subsequent
> breeders in the US and internationally.

---

## Edit 11: Add missing traits in a batch (one short section each)

**Where to insert:** Near the end of the morph list, before the "Wild
Crested Gecko Morphs" entry. You can add each as an H4 heading with a
short paragraph.

```html
<h4>Highway Crested Gecko Morphs</h4>
<p>Highway is an incomplete dominant trait and the third known allele in
the Sable/Cappuccino allelic complex. Highway × Cappuccino and Highway ×
Sable produce distinct compound heterozygote phenotypes.
⚠️ Super Highway has documented complications — use caution in pairing.
Source: <a href="https://reptidex.com/genetics/crested-gecko"
target="_blank" rel="noopener">ReptiDex</a>.</p>

<h4>Softscale Crested Gecko Morphs</h4>
<p>Softscale is an incomplete dominant structural trait producing matte
coloration and a smooth scale appearance. Heterozygous animals show a
moderate matte effect; homozygous Super Softscales display enhanced
matte appearance and pronounced scale spacing.</p>

<h4>Snowflake Crested Gecko Morphs</h4>
<p>Snowflake creates white spotting or flecking in a snowflake-like
pattern. It's epistatic to White Pattern — meaning Snowflake requires
White Pattern to express. Synergistic with Lilly White to produce
near-full white coverage animals.</p>

<h4>Pixel Crested Gecko Morphs</h4>
<p>Pixel is a recessive pattern disruptor that fractures and scatters
white and orange patterns into a pixelated appearance. It affects
tigering, pattern distribution, and pinning across the dorsum and
laterals, creating distinctly jagged, pixelated edges rather than
smooth pattern boundaries.</p>

<h4>Fire / Blizzard Crested Gecko Morphs</h4>
<p>Fire is an incomplete dominant trait that reduces melanin and dark
pigmentation. The homozygous super form is called Black Eyed Leucistic
(BEL) or Blizzard and displays white body with yellow pigment retention
and black eyes. Multiple Fire lines exist from different breeders
(Genetic Hypo, Pinky, GhostPax, The Bugg Plug's Blizzard) — they have
<strong>not been proven genetically compatible</strong>, and crossing
lines may not produce BEL offspring.</p>

<h4>ChoCho Crested Gecko Morphs</h4>
<p>ChoCho is a simple recessive trait affecting red/tangerine pigment
display and age-dependent color change. Hatchlings emerge extremely
vibrant or "radioactive" orange and darken dramatically with age —
the opposite of normal Red Base animals which hatch brown and gain
color. Adults show maroon body coloration with a distinctive dark red
head stamp and pink/tangerine tail coating.</p>

<h4>Empty Back Crested Gecko Morphs</h4>
<p>Empty Back is an incomplete dominant trait that reduces or eliminates
dorsal pattern coloring while retaining pattern structure on the sides.
Heterozygous animals show moderate pattern reduction on the back;
homozygous Super Empty Backs show extensive back clearing. Antagonistic
with Harlequin — the two traits compete for pattern control.</p>

<h4>Luwak Crested Gecko Morphs</h4>
<p>Luwak is the compound heterozygote of Cappuccino + Sable. Because
Sable and Cappuccino are allelic (same gene locus, different alleles),
an animal with one copy of each expresses a unique combined phenotype
rather than a Super Cappuccino. Named after the Indonesian coffee
variety kopi luwak.</p>

<h4>Frappuccino Crested Gecko Morphs</h4>
<p>Frappuccino is a combo morph: Cappuccino + Lilly White. Frappuccinos
hatch with a brighter, whiter coloration than a standard Lilly White
and develop dramatic changes by adulthood, including white spotting on
the head. A Phantom Frappuccino adds the recessive Phantom gene for a
three-gene combination. Source:
<a href="https://lmreptiles.com/fg-pt2-capps/" target="_blank"
rel="noopener">LM Reptiles Cappuccino Guide</a>.</p>
```

---

## Edit 12: Update the Extreme Harlequin / XXX section

**Locate this heading:** `Extreme Harlequin Crested Gecko Morphs`

### BEFORE
> Extreme harlequin crested geckos dorsal patterning is minimal creeping up
> into the stripe. Some people refer to the extreme harlequins as 'high
> expression' crested geckos. Or they may say, 'look at the high expression
> on this gecko.'

### AFTER
> Extreme Harlequin crested geckos display maximum pattern concentration,
> with pattern covering approximately 75% or more of the body and
> connecting the dorsal and lateral regions. The Harlequin gene (HQ) is
> incomplete dominant, and Extreme Harlequin phenotypes approach
> homozygous HQ/HQ expression. These are also commonly called "high
> expression" harlequins.
>
> <strong>Note on "XXX":</strong> "XXX" is a marketing term coined by
> <a href="https://www.pangeareptile.com/" target="_blank"
> rel="noopener">Matt Parks at Pangea Reptile</a> for phenotypically
> extreme Harlequin animals. It is <strong>not</strong> a proven genetic
> designation — XXX animals are not necessarily genetically homozygous
> for Harlequin. Source:
> <a href="https://lmreptiles.com/fg-pt2-1/" target="_blank"
> rel="noopener">Foundation Genetics Part 2.1</a>.

---

## Edit 13: Update page title and meta description

**In WordPress:** Edit Post → SEO / Yoast (or whatever your SEO plugin is)
→ update the following fields.

### Current
- Page Title: `Crested Gecko Morphs - Tenny's Crested Geckos`
- Meta Description: (likely absent or default)

### Recommended
- **Page Title:** `Crested Gecko Morphs (2026): Complete Genetics, Traits & Breeding Guide | Tenny's Crested Geckos`

- **Meta Description:** `The complete crested gecko morph guide based on Foundation Genetics research. Covers Lilly White, Cappuccino, Phantom, Axanthic, Whiteout, Sable, and all 30+ traits with inheritance patterns, breeding warnings, and citations from top breeders. Updated April 2026.`

### URL slug
Keep as `/crested-gecko-morphs/` — you don't want to change the URL since
it has existing search equity. If you rebuild the URL structure later,
set up 301 redirects.

### Alt text for images
For SEO, any new images added should have alt text like:
- `"Lilly White crested gecko displaying white dorsal and lateral scales"`
- `"Super Cappuccino (Melanistic) crested gecko showing jet-black coloration and black eyes"`
- `"Tricolor Extreme Harlequin crested gecko with white and orange pattern"`

---

## Edit 14: Add a "Last Updated" banner near the top

**Where to insert:** Right under the main H1 `Crested Gecko Morphs`.

```html
<p style="background: #f8f4e6; border-left: 4px solid #b8860b;
padding: 12px 16px; margin: 16px 0; font-size: 0.95em;">
<strong>Last updated: April 2026.</strong> This guide reflects the current
Foundation Genetics consensus as established by Lil Monsters Reptiles,
Geckological, and contributing breeders through April 2026. For the
complete technical reference, see
<a href="https://lmreptiles.com/fg-overview/" target="_blank"
rel="noopener">LM Reptiles' Foundation Genetics project</a>.
</p>
```

This one small addition materially improves AI SEO performance —
generative search engines heavily prioritize recently-updated content
and having an explicit "last updated" date.

---

## Order of operations checklist

Do these in this order for maximum SEO impact with minimum risk:

- [ ] Edit 1: Fix Cappuccino "codominant"
- [ ] Edit 2: Fix Patternless/Phantom
- [ ] Edit 3: Add Lilly lethality warning
- [ ] Edit 4: Update Dalmatian inheritance
- [ ] Edit 5: Rewrite Phantom section
- [ ] Edit 6: Replace Moonglow entry
- [ ] Edit 14: Add "Last Updated" banner (quick win)
- [ ] Edit 13: Update page title and meta description
- [ ] Edit 7: Add Foundation Genetics primer section
- [ ] Edit 8: Add Whiteout section
- [ ] Edit 9: Add Sable section
- [ ] Edit 10: Expand Axanthic section
- [ ] Edit 11: Add the 8 new trait sections (Highway, Softscale, Snowflake, Pixel, Fire/Blizzard, ChoCho, Empty Back, Luwak, Frappuccino)
- [ ] Edit 12: Update Extreme Harlequin section

After all edits: request Google re-index via Search Console, and
submit the updated URL to Bing Webmaster Tools. AI search engines
(Perplexity, ChatGPT, Claude) will pick up the changes on their next
crawl cycle (typically 1–4 weeks).
