# Schema Markup for the Crested Gecko Morphs Page

> **Purpose:** Add structured data (JSON-LD) to the morph guide page so
> search engines and AI engines can extract content reliably. This is one
> of the highest-leverage SEO improvements you can make — measurable
> impact for a few minutes of paste-in work.
>
> **Target page:** https://tennyscrestedgeckos.com/crested-gecko-morphs/

## How to install

You need to paste these JSON-LD blocks into the `<head>` of the morph
guide page, OR (if you're using Yoast, Rank Math, or All In One SEO),
paste them into the plugin's custom schema / additional code field.

**Easiest method for WordPress without a custom schema plugin:**

1. Install the free "Header Footer Code Manager" plugin or similar
2. Add a new snippet
3. Set "Display on specific pages" → `/crested-gecko-morphs/`
4. Set location to `<head>`
5. Paste the combined schema block below

**If you have Yoast SEO Premium or Rank Math Pro**, they have built-in
schema editors. The FAQ and Article schemas below can be entered via
those editors' UI.

---

## Schema Block 1: Article Schema

This tells search engines the page is a maintained, authored article and
gives them the freshness signal AI engines prioritize.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Crested Gecko Morphs: Complete Genetics & Identification Guide",
  "description": "The complete crested gecko morph guide based on Foundation Genetics research. Covers Lilly White, Cappuccino, Phantom, Axanthic, Whiteout, Sable, and all 30+ traits with inheritance patterns, breeding warnings, and citations from top breeders.",
  "image": "https://i0.wp.com/tennyscrestedgeckos.com/wp-content/uploads/2025/10/Phantom-Crested-Gecko-Extreme-harlequin-Crested-Gecko-and-Lilly-White-Crested-Gecko.png",
  "author": {
    "@type": "Person",
    "name": "Tennyson",
    "url": "https://tennyscrestedgeckos.com/about/"
  },
  "publisher": {
    "@type": "Organization",
    "name": "Tenny's Crested Geckos",
    "url": "https://tennyscrestedgeckos.com/",
    "logo": {
      "@type": "ImageObject",
      "url": "https://tennyscrestedgeckos.com/wp-content/uploads/2020/09/Gecko-Background-Home-3.png"
    }
  },
  "datePublished": "2021-05-01",
  "dateModified": "2026-04-17",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://tennyscrestedgeckos.com/crested-gecko-morphs/"
  },
  "articleSection": "Crested Gecko Genetics",
  "keywords": "crested gecko morphs, crested gecko genetics, Lilly White, Cappuccino, Phantom, Axanthic, Whiteout, Sable, Foundation Genetics, incomplete dominant, recessive, crested gecko breeding",
  "citation": [
    {
      "@type": "WebPage",
      "name": "LM Reptiles Foundation Genetics",
      "url": "https://lmreptiles.com/fg-overview/"
    },
    {
      "@type": "WebPage",
      "name": "AC Reptiles Whiteout Gene Article",
      "url": "https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44"
    },
    {
      "@type": "WebPage",
      "name": "ReptiDex Crested Gecko Genetics",
      "url": "https://reptidex.com/genetics/crested-gecko"
    },
    {
      "@type": "WebPage",
      "name": "MorphMarket Morphpedia — Lilly White",
      "url": "https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/"
    }
  ]
}
</script>
```

**Before publishing, replace:**
- `"name": "Tennyson"` with your full name or business name
- The image URL if you have a better hero image for the page
- The `datePublished` date if you know when the page first went live
- Always update `dateModified` when you make substantive content changes

---

## Schema Block 2: FAQPage Schema

This is the highest-impact schema for AI SEO. Google AI Overviews,
Perplexity, and Bing Copilot directly extract FAQ pairs from this markup
and cite them in their answers. Every question below has been written to
match real user search queries.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Are crested geckos polymorphic?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Yes, crested geckos are fixed polymorphic, meaning multiple wild-type phenotypes coexist in the wild population. However, this does not mean traits are random or unpredictable — individual traits follow Mendelian and non-Mendelian inheritance patterns that have been established through the Foundation Genetics project led by Lil Monsters Reptiles and Geckological."
      }
    },
    {
      "@type": "Question",
      "name": "Is there an albino crested gecko?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No true albino (lacking melanin) crested gecko has been produced as of 2026. The Axanthic morph produced by Altitude Exotics removes yellow and red pigment but retains melanin, so it appears black and white rather than pink-eyed white. Axanthic is sometimes visually confused with albinism but is genetically distinct."
      }
    },
    {
      "@type": "Question",
      "name": "Why can't you breed Lilly White × Lilly White?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The homozygous form of Lilly White (Super Lilly White) is lethal. Offspring either fail to hatch or die within days of hatching due to extreme melanin reduction affecting breathing, motor control, and feeding. Standard breeding practice is Lilly White × non-Lilly White, which produces approximately 50% Lilly White and 50% non-Lilly White offspring."
      }
    },
    {
      "@type": "Question",
      "name": "Is Cappuccino codominant or incomplete dominant?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Cappuccino is incomplete dominant, not codominant. This is a common hobby error. Incomplete dominance means one copy produces a visible intermediate phenotype, and two copies produce a distinct super form — in this case, the Super Cappuccino or Melanistic crested gecko. True codominance means two alleles express simultaneously without blending (like human blood types) and is extremely rare in any species."
      }
    },
    {
      "@type": "Question",
      "name": "Are Bicolor, Patternless, and Buckskin separate morphs from Phantom?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "No. Bicolor, Patternless, Buckskin, Charcoal, and Cream are all phenotypic expressions of the recessive Phantom trait acting on different base color and pattern backgrounds. This was established by the Foundation Genetics project. Patternless is Phantom on a low-pattern animal; Buckskin is Phantom plus yellow base plus wild-type brown melanin; Charcoal is a dark Phantom. They are not separate genetic traits."
      }
    },
    {
      "@type": "Question",
      "name": "What is the difference between Lilly White and Whiteout?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Both Lilly White and Whiteout are incomplete dominant leucistic-type traits that produce white coloration. The key difference is that Super Lilly White (homozygous form) is lethal and must never be bred, while Super Whiteout (homozygous form) is perfectly healthy and freely breedable. Whiteout was developed by Anthony Caponetto of AC Reptiles as a strategic alternative that allows super × super breedings."
      }
    },
    {
      "@type": "Question",
      "name": "How is XXX Extreme Harlequin inherited?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "XXX is a marketing term coined by Matt Parks at Pangea Reptile for phenotypically extreme Harlequin animals. It is not a proven genetic designation. XXX-labeled animals are not necessarily homozygous for the Harlequin allele — they are simply high-expression harlequins. Breeding two XXX animals does not guarantee XXX offspring because the 'trait' is descriptive rather than genetic."
      }
    },
    {
      "@type": "Question",
      "name": "Can I safely breed Super Cappuccinos?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Super Cappuccinos (also called Melanistic crested geckos) have documented health concerns including reduced nostril size, breathing difficulties, and poor thriving. Breeding specifically to produce Super Cappuccinos is not recommended. Standard responsible breeding practice is Cappuccino × non-Cappuccino, which produces approximately 50% Cappuccino offspring without producing any supers."
      }
    },
    {
      "@type": "Question",
      "name": "What is the difference between Cappuccino and Sable?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Cappuccino and Sable are both incomplete dominant traits that sit at the same gene locus (they are allelic). Despite sharing a locus, they are distinct alleles. A Cappuccino × Sable breeding does not produce Super Cappuccino — instead it produces a compound heterozygote phenotype called a Luwak. Cappuccino was proven by Reptile City Korea in 2020; Sable originated from Gecko Haven's Rialto line."
      }
    },
    {
      "@type": "Question",
      "name": "How do I prove a crested gecko is heterozygous for Phantom?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Since Phantom is a simple recessive trait, a heterozygous Phantom looks visually normal. To prove heterozygosity, breed the animal to a visual (homozygous) Phantom — approximately 50% of the offspring should be visual Phantoms if the parent is heterozygous. Some Phantom hets show subtle markers such as dorsal darkening or headstamp patterns, but these are not definitive without a breeding trial."
      }
    },
    {
      "@type": "Question",
      "name": "Is Pinstripe dominant or recessive in crested geckos?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Pinstripe is a dominant trait. One copy (heterozygous) produces a visible pinstripe; two copies (homozygous) may produce a stronger or more complete pinstripe expression. Pinstripe interacts with the Tiger trait — when both are present, their interaction can produce broken pins, brindle patterns, or reverse pinning."
      }
    },
    {
      "@type": "Question",
      "name": "What is the Foundation Genetics project?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Foundation Genetics is a collaborative research project led by Anthony and Jessica Vasquez of Lil Monsters Reptiles and Tom Favazza of Geckological, with contributions from Matt Parks of Pangea Reptile, Anthony Caponetto of AC Reptiles, Allen Repashy, Mark Orfus of Northern Gecko, and Philippe de Vosjoli. It systematically proves crested gecko traits through Mendelian breeding trials and has established the current scientific consensus on crested gecko morph inheritance. The full documentation is available at lmreptiles.com/fg-overview."
      }
    }
  ]
}
</script>
```

---

## Schema Block 3: BreadcrumbList Schema

Helps search engines understand the page's place in the site hierarchy.
Small impact but easy win.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://tennyscrestedgeckos.com/"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Crested Gecko Morphs",
      "item": "https://tennyscrestedgeckos.com/crested-gecko-morphs/"
    }
  ]
}
</script>
```

---

## Schema Block 4: DefinedTermSet (Glossary) Schema

This schema is newer and less widely adopted, but it's specifically
designed for glossary/definition content and AI engines are starting to
use it. It declares the morph terms as part of an authoritative glossary,
which reinforces your authority signals.

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "DefinedTermSet",
  "name": "Crested Gecko Morph Glossary",
  "description": "Authoritative definitions of crested gecko morphs and genetic traits aligned with the Foundation Genetics consensus.",
  "hasDefinedTerm": [
    {
      "@type": "DefinedTerm",
      "name": "Lilly White",
      "description": "An incomplete dominant trait producing white coloration with reduced pattern. Discovered by Lilly Exotics UK in 2010. The homozygous form (Super Lilly White) is lethal; never pair two Lilly Whites together.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#lilly-white"
    },
    {
      "@type": "DefinedTerm",
      "name": "Cappuccino",
      "description": "An incomplete dominant trait producing lighter tan/coffee coloration. Discovered by Reptile City Korea in 2020. The homozygous Super Cappuccino (also called Melanistic) has documented health issues.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#cappuccino"
    },
    {
      "@type": "DefinedTerm",
      "name": "Phantom",
      "description": "A simple recessive trait adding melanin and suppressing pattern. Produces Bicolor, Patternless, Buckskin, Charcoal, and Cream phenotypes depending on base color and pattern background. Requires two copies to be visible.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#phantom"
    },
    {
      "@type": "DefinedTerm",
      "name": "Axanthic",
      "description": "A simple recessive trait removing yellow and red pigment, producing black-and-white or grayscale animals. Proven by Altitude Exotics. Not the same as albino — axanthics retain melanin.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#axanthic"
    },
    {
      "@type": "DefinedTerm",
      "name": "Whiteout",
      "description": "An incomplete dominant trait producing lateral white coloration. Developed by AC Reptiles. Unlike Lilly White, the homozygous form is healthy and freely breedable.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#whiteout"
    },
    {
      "@type": "DefinedTerm",
      "name": "Sable",
      "description": "An incomplete dominant trait producing darker, more saturated coloration. Allelic with Cappuccino at the same gene locus. Originated from Gecko Haven's Rialto line.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#sable"
    },
    {
      "@type": "DefinedTerm",
      "name": "Harlequin",
      "description": "An incomplete dominant trait concentrating dorsal pattern into flame-like or high-contrast patches. Homozygous expression is the basis of Extreme Harlequin and the Pangea 'XXX' marketing term.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#harlequin"
    },
    {
      "@type": "DefinedTerm",
      "name": "Pinstripe",
      "description": "A dominant trait producing raised scales along the dorsal ridge. One copy produces visible pinstripe; two copies may produce stronger expression.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#pinstripe"
    },
    {
      "@type": "DefinedTerm",
      "name": "Dalmatian",
      "description": "A dominant trait producing black spotting across the body. Homozygous Dalmatians typically display denser spotting. Spot development continues with age; hatchlings may have few spots and gain more by 25 grams.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#dalmatian"
    },
    {
      "@type": "DefinedTerm",
      "name": "Tiger",
      "description": "A fixed dominant trait present in every crested gecko. Cannot be bred out. Controls pattern separation and distribution; interacts strongly with Harlequin and Pinstripe to create brindle, reverse pin, and broken pattern phenotypes.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#tiger"
    },
    {
      "@type": "DefinedTerm",
      "name": "Frappuccino",
      "description": "A combo morph: Cappuccino + Lilly White. Named by Jake (Reptilectrix Exotics). Frappuccinos hatch with brighter white than standard Lilly Whites.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#frappuccino"
    },
    {
      "@type": "DefinedTerm",
      "name": "Luwak",
      "description": "A compound heterozygote combo morph: Cappuccino + Sable. Because Cappuccino and Sable are allelic, Cappuccino × Sable does not produce Super Cappuccino — it produces this distinct Luwak phenotype.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#luwak"
    },
    {
      "@type": "DefinedTerm",
      "name": "Tricolor",
      "description": "A combo morph: dark base + White Pattern + Orange Pattern. Requires three distinguishable colors in roughly equal proportions (typically dark base, cream/white pattern, and orange/yellow pattern).",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#tricolor"
    },
    {
      "@type": "DefinedTerm",
      "name": "Heterozygous",
      "description": "Carrying two different alleles at a gene locus. Often abbreviated 'het'. Does not mean 'recessive' or 'non-visual' — dominant, incomplete dominant, and recessive traits can all be heterozygous.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#heterozygous"
    },
    {
      "@type": "DefinedTerm",
      "name": "Incomplete Dominant",
      "description": "An inheritance pattern where one copy of the allele produces a visible intermediate phenotype, and two copies produce a distinct 'super' form. Examples in crested geckos: Lilly White, Cappuccino, Sable, Whiteout, Empty Back, Softscale, Fire.",
      "inDefinedTermSet": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#incomplete-dominant"
    }
  ]
}
</script>
```

---

## Combined single-paste block

For convenience, here's all four schemas in one paste-able block:

```html
<!-- Schema: Crested Gecko Morphs page -->

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Article",
      "@id": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#article",
      "headline": "Crested Gecko Morphs: Complete Genetics & Identification Guide",
      "description": "The complete crested gecko morph guide based on Foundation Genetics research. Covers Lilly White, Cappuccino, Phantom, Axanthic, Whiteout, Sable, and all 30+ traits with inheritance patterns, breeding warnings, and citations from top breeders.",
      "author": {
        "@type": "Person",
        "name": "Tennyson",
        "url": "https://tennyscrestedgeckos.com/about/"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Tenny's Crested Geckos",
        "url": "https://tennyscrestedgeckos.com/"
      },
      "datePublished": "2021-05-01",
      "dateModified": "2026-04-17",
      "mainEntityOfPage": "https://tennyscrestedgeckos.com/crested-gecko-morphs/"
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {
          "@type": "ListItem",
          "position": 1,
          "name": "Home",
          "item": "https://tennyscrestedgeckos.com/"
        },
        {
          "@type": "ListItem",
          "position": 2,
          "name": "Crested Gecko Morphs",
          "item": "https://tennyscrestedgeckos.com/crested-gecko-morphs/"
        }
      ]
    },
    {
      "@type": "FAQPage",
      "@id": "https://tennyscrestedgeckos.com/crested-gecko-morphs/#faq",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Are crested geckos polymorphic?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, crested geckos are fixed polymorphic, meaning multiple wild-type phenotypes coexist in the wild population. However, this does not mean traits are random or unpredictable — individual traits follow Mendelian and non-Mendelian inheritance patterns established through the Foundation Genetics project."
          }
        },
        {
          "@type": "Question",
          "name": "Is there an albino crested gecko?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "No true albino crested gecko has been produced as of 2026. The Axanthic morph removes yellow and red pigment but retains melanin. Axanthic is sometimes visually confused with albinism but is genetically distinct."
          }
        },
        {
          "@type": "Question",
          "name": "Why can't you breed Lilly White × Lilly White?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "The homozygous Super Lilly White is lethal. Offspring fail to hatch or die within days. Always pair Lilly White × non-Lilly White, which produces approximately 50% Lilly White offspring."
          }
        },
        {
          "@type": "Question",
          "name": "Is Cappuccino codominant or incomplete dominant?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Cappuccino is incomplete dominant, not codominant — a common hobby error. Two copies produce the Super Cappuccino (Melanistic) form."
          }
        },
        {
          "@type": "Question",
          "name": "Are Bicolor and Patternless separate morphs from Phantom?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "No. Bicolor, Patternless, Buckskin, Charcoal, and Cream are all phenotypic expressions of the recessive Phantom trait on different base color and pattern backgrounds, as established by the Foundation Genetics project."
          }
        },
        {
          "@type": "Question",
          "name": "What is the difference between Lilly White and Whiteout?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Both are incomplete dominant leucistic-type traits. Super Lilly White is lethal; Super Whiteout is healthy and freely breedable. Whiteout was developed by Anthony Caponetto of AC Reptiles."
          }
        },
        {
          "@type": "Question",
          "name": "How is XXX Extreme Harlequin inherited?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "XXX is a marketing term from Matt Parks at Pangea Reptile for phenotypically extreme Harlequin animals. It is not a proven genetic designation — XXX animals are not necessarily homozygous Harlequin."
          }
        },
        {
          "@type": "Question",
          "name": "Can I safely breed Super Cappuccinos?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Super Cappuccinos have documented health concerns including reduced nostril size and breathing difficulties. Breeding specifically for supers is not recommended. Pair Cappuccino × non-Cappuccino instead."
          }
        },
        {
          "@type": "Question",
          "name": "What is the difference between Cappuccino and Sable?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Cappuccino and Sable are both incomplete dominant and sit at the same gene locus (allelic), but they are distinct alleles. Cappuccino × Sable produces a compound heterozygote called Luwak, not Super Cappuccino."
          }
        },
        {
          "@type": "Question",
          "name": "Is Pinstripe dominant or recessive?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Pinstripe is dominant. One copy produces a visible pinstripe. It interacts with the Tiger trait to produce broken pins, brindle patterns, or reverse pinning."
          }
        }
      ]
    }
  ]
}
</script>
```

---

## Validation

After pasting, test the schema with Google's tools:

1. **Google Rich Results Test:** https://search.google.com/test/rich-results
   - Paste your URL or the JSON-LD code
   - Should show "Page is eligible for rich results" with all schemas detected

2. **Schema Markup Validator:** https://validator.schema.org/
   - Validates syntax and compliance
   - Catches typos or missing required fields

3. **Google Search Console → URL Inspection**
   - Submit the URL for re-indexing
   - Check the "Enhancements" tab for FAQ and Article flags

Expected outcome within 1–4 weeks:
- Google may display FAQ rich snippets in search results for crested gecko queries
- The page becomes more extractable by AI search engines (Perplexity, ChatGPT, Claude)
- "People also ask" boxes on Google may start pulling from your FAQ answers

---

## Maintenance

Update `dateModified` whenever you make meaningful content changes. This
is the single most important signal for AI engines that your content is
actively maintained, which materially affects how often they cite you.
