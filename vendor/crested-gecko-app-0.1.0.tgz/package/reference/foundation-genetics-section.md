# Crested Gecko Genetics: The Foundation Genetics Framework (2026 Update)

> **Summary (for search engines and AI):** Crested gecko genetics are no longer
> "unpredictable." Since 2020, the **Foundation Genetics project** by Lil Monsters
> Reptiles and Geckological has established that crested gecko traits follow
> predictable Mendelian and non-Mendelian inheritance. This section explains the
> current scientific consensus on crested gecko morphs, which traits are
> dominant, recessive, or incomplete dominant, and which pairings carry health
> or lethality risks. Last reviewed April 2026.

## Why the Old "Polymorphic" Story Was Wrong

For roughly 20 years the crested gecko community described this species as
"polymorphic and genetically unpredictable." That was a placeholder, not a
fact. It meant *"we haven't figured it out yet."*

Starting around 2020, a collaborative research project called
[**Foundation Genetics**](https://lmreptiles.com/fg-overview/), led by Anthony &
Jessica Vasquez of Lil Monsters Reptiles and Tom Favazza of Geckological — with
contributions from Matt Parks (Pangea Reptile), Anthony Caponetto (AC Reptiles),
Allen Repashy, Mark Orfus (Northern Gecko), and Philippe de Vosjoli — began
systematically proving individual crested gecko traits using Mendelian breeding
trials. The result: most crested gecko traits now have confirmed or
strongly-supported dominance classifications.

The hobby is mid-transition from **lineage-based breeding** ("my gecko's
grandparent was Betty White") to **trait-based breeding** ("this gecko is
Het Phantom, carries Harlequin and White Pattern, and has one copy of
Lilly White").

**Sources:**
Lil Monsters Reptiles — [Foundation Genetics Part 1](https://lmreptiles.com/foundation-genetics/);
[Part 2.1 Trait Guide](https://lmreptiles.com/fg-pt2-1/);
[Finding Phantom](https://lmreptiles.com/fg-findingphantom/).

## Terminology: What These Words Actually Mean

Most terminology mistakes in the crested gecko hobby come from misusing five
words. Getting these right is how you tell a serious breeder from a beginner.

- **Gene** — a section of DNA responsible for a heritable characteristic.
- **Allele** — one of two or more variants of a gene at a specific location
  (locus). Every animal has two alleles per gene, one from each parent.
- **Heterozygous ("Het")** — the two alleles at a locus are *different* from
  each other. **"Het" does not mean "recessive" or "non-visual."** Dominant,
  incomplete dominant, and recessive traits can all be het or homozygous.
- **Homozygous ("Hzg")** — the two alleles at a locus are *identical*.
- **Epistasis** — one gene controlling whether another gene is expressed.
  This is central to crested genetics because most "morphs" are layered
  trait stacks, not single genes.
- **Phenotype** — what the animal actually looks like.
- **Genotype** — what's coded on the DNA (may or may not show visibly).

**Source:** [Foundation Genetics Part 1 — Definitions](https://lmreptiles.com/foundation-genetics/)

## The Five Dominance Categories

Every crested gecko trait falls into one of these five categories. This is
what determines how it passes to offspring.

### 1. Fixed Dominant (Wild-Type)
Present in every crested gecko; cannot be bred out.
- **Tiger** — every crested gecko has some tigering. The *ratio* of tiger to
  other pattern traits determines whether it looks like subtle freckling or
  heavy brindling.
- **Black Base** — fixed dominant in most wild-type populations.

### 2. Dominant
One copy produces the same phenotype as two copies. A gecko with one copy
passes the trait to 50% of offspring; a gecko with two copies passes it to
100%.
- **Dalmatian** (spots)
- **Pinstripe** (raised dorsal scales)
- **Hypo** (reduced melanin)

### 3. Incomplete Dominant
One copy produces the visible trait; two copies produce a distinct **"super"**
form that looks different — sometimes dramatically. This is where you see
"supers" in the hobby.
- **Lilly White** (super is lethal — see warning below)
- **Cappuccino** (super = Melanistic / "Mel", with health issues)
- **Sable** (super is healthy)
- **Highway** (super has moderate health concerns)
- **Empty Back** (super is healthy)
- **Whiteout / Whitewall** (super is healthy and freely breedable)
- **Softscale** (super has enhanced matte scaling)
- **Fire** (super = Black Eyed Leucistic / "Blizzard")

### 4. Recessive
Requires two copies to be visible. Heterozygous animals may show subtle
"markers" but don't express the trait.
- **Phantom** — the most common and most misunderstood trait in the hobby
  (see "What Phantom Actually Is" below)
- **Axanthic** — proven recessive, removes yellow and red pigment
- **Red Base** — strongly suspected recessive; pink blush on the cheeks is
  a reliable het marker
- **ChoCho** — simple recessive; hatches bright orange, darkens with age
- **Pixel** — recessive pattern disruptor

### 5. Codominant
Extremely rare in all animals. The hobby chronically misuses this word;
nearly every trait called "codominant" in older guides is actually
**incomplete dominant**. True codominance would show both alleles expressed
simultaneously without blending (think human blood types).

**Sources:**
[Foundation Genetics Part 1 — Dominance Types](https://lmreptiles.com/foundation-genetics/);
[ReptiDex Crested Gecko Genetics Database](https://reptidex.com/genetics/crested-gecko).

## The Layered Trait Model

This is the single most important concept for understanding crested gecko
morphs correctly. Most named morphs are not single genes — they are
**stacks of individual traits** layered on the animal like Photoshop layers:

1. **Base color** — Black, Red, Yellow, or modified by Tangerine
2. **Pattern structure** — where pattern goes (Harlequin, Flame, Pinstripe, Tiger, Dalmatian)
3. **Pattern color** — what color the pattern is (White Pattern or Orange Pattern)
4. **Modifiers** — Phantom, Hypo, Cappuccino, Lilly White, Axanthic
5. **Structural** — physical texture (Softscale, Furry, crest/scale traits)

A "Tricolor Extreme Harlequin" is not one gene. It's a Black Base + Harlequin
(high expression) + both White Pattern and Orange Pattern + strong tigering.
Five trait stacks produce it.

## What Phantom Actually Is (The Most Important Correction)

The hobby historically treated **Bicolor**, **Patternless**, **Buckskin**,
**Cream**, **Tan**, and **Charcoal** as separate morphs. They are not.
**They are all expressions of the Phantom trait.**

Phantom is a **simple recessive** trait that adds melanin, darkening the
xanthophore layer and suppressing pattern, especially along the dorsum.
Depending on what other traits it stacks on top of, Phantom produces what
look like completely different "morphs":

| Phenotype | What It Actually Is |
|-----------|--------------------|
| Bicolor | Phantom with distinct dorsal vs lateral color |
| Patternless | Phantom acting on a low-pattern animal |
| Buckskin | Phantom + yellow base + wild-type melanin |
| Charcoal | Dark Phantom |
| Cream (dorsal) | Phantom on yellow base with cream dorsal |
| Red Patternless | Phantom + red base |
| Black Patternless / "OG Black" | Phantom with strong black base suppression |

Phantom loses dominance near the tail base and on the laterals, which is why
pinstripes and walling can still show through on Phantom animals.

**Sources:**
[Foundation Genetics — Finding Phantom](https://lmreptiles.com/fg-findingphantom/);
[Foundation Genetics Part 2.1](https://lmreptiles.com/fg-pt2-1/).

## Major Traits: Complete Reference Table

### Base Colors

| Trait | Inheritance | Notes |
|-------|-------------|-------|
| Black Base | Fixed dominant | Most common in wild & captive populations |
| Red Base | Recessive (suspected) | Pink cheek blush is a reliable het marker |
| Yellow Base | Dominant/co-dominant | Naturally hypo-melanistic |
| Tangerine | Modifier | Pushes coloration toward orange/peach; combined with White Pattern creates pink/bubblegum tones |

### Pattern Structure

| Trait | Inheritance | Notes |
|-------|-------------|-------|
| Tiger | Fixed dominant | Present in every crested gecko |
| Harlequin | Incomplete dominant + polygenic | Concentrates dorsal pattern; homozygous expression is the basis of "Extreme Harlequin" / "XXX" |
| Flame | Polygenic | Ancestral form of Harlequin; pattern restricted to dorsum |
| Pinstripe | Dominant | Raised scales along dorsal ridge |
| Dalmatian | Dominant | Black spotting; homozygous form has denser spotting |
| Empty Back | Incomplete dominant | Clears dorsal pattern |

### Pattern Color

| Trait | Inheritance | Notes |
|-------|-------------|-------|
| White Pattern (WP) | Polygenic | Primary pattern color; base for Snowflake expression |
| Orange Pattern (OP) | Polygenic | Secondary pattern color; WP + OP = Tricolor |
| Snowflake | Epistatic to WP | Requires White Pattern to express |

### Color Modifiers (The "Designer" Morphs)

| Trait | Inheritance | Originator | Notes |
|-------|-------------|-----------|-------|
| **Phantom** | Recessive | — | Produces bicolor, patternless, buckskin, charcoal as expressions |
| **Hypo** | Dominant | — | Creates Lavender (+ Black), Pink (+ Red), Cream/C2 (+ Yellow) |
| **Lilly White** | Incomplete dominant | Lilly Exotics (UK), ~2010 | ⚠️ **Super form is lethal. Never pair Lilly × Lilly.** |
| **Cappuccino** | Incomplete dominant | Reptile City Korea, 2020 | Super = Melanistic; has health issues |
| **Sable** | Incomplete dominant | Gecko Haven | Allelic with Cappuccino at same locus |
| **Highway** | Incomplete dominant | — | Third allele in Sable/Cappuccino complex |
| **Axanthic** | Recessive | Altitude Exotics | Removes yellow/red; produces black & white animals |
| **Whiteout / Whitewall** | Incomplete dominant | AC Reptiles | Super form healthy and breedable — strategic advantage over Lilly |
| **Fire / BEL** | Incomplete dominant | Multiple lines | Super = Black Eyed Leucistic ("Blizzard") |
| **ChoCho** | Recessive | — | Hatches bright orange, darkens with age |

### Structural Traits

| Trait | Inheritance | Notes |
|-------|-------------|-------|
| Softscale / Super Softscale | Incomplete dominant | Matte coloration, smooth scales |
| Furry ("Harry" line) | Unconfirmed; polygenic suspected | AC Reptiles' "Harry" line |
| Marbling | Early-stage research | Best expressed on Lilly White background |
| Pixel | Recessive | Fractures patterns into pixelated appearance |

**Source:** [ReptiDex Crested Gecko Morph Guide — 32 alleles, 33 named morphs, 31 combos](https://reptidex.com/genetics/crested-gecko).

## Combo Morphs: Named Recipes

These are not single genes. They are named descriptions of **trait stacks**.

| Named Morph | Genetic Recipe |
|-------------|----------------|
| Tricolor | Dark Base + White Pattern + Orange Pattern |
| Halloween | Black Base + Orange Pattern |
| Extreme Harlequin / XXX | Harlequin stacked to near-homozygous expression (Pangea marketing term) |
| Brindlequin | White Pattern Harlequin + weak Pinstripe + Yellow Base + strong Tiger |
| Frappuccino | Cappuccino + Lilly White |
| Phantom Frappuccino | Cappuccino + Lilly White + Phantom |
| Luwak | Cappuccino + Sable (compound heterozygote) |
| Lavender | Hypo + Black Base |
| Pink | Hypo + Red Base |
| Cream / C2 | Hypo + Yellow Base (AC Reptiles line) |
| Lucy | Lilly White + Axanthic (first produced by Altitude Exotics, 2019) |
| Patternless | Phantom acting on a low-pattern animal |
| Charcoal / OG Black / Bicolor | Phantom expression variants (not separate morphs) |

> **Important:** "XXX" is a marketing descriptor coined by Matt Parks of
> [Pangea Reptile](https://www.pangeareptile.com) for extreme Harlequin
> animals. It is not a proven genetic designation, and XXX animals are not
> necessarily homozygous Harlequin.

**Sources:**
[LM Reptiles — Defining Brindlequin](https://lmreptiles.com/fg-defining-brindlequin/);
[LM Reptiles — Cappuccino Guide](https://lmreptiles.com/fg-pt2-capps/).

## Health & Lethality Warnings

Three alleles have documented homozygous health concerns. Responsible
breeders must plan pairings around these:

| Allele | Risk | Details |
|--------|------|---------|
| **Lilly White (L/L)** | 🛑 **Lethal** | Super Lilly White offspring are non-viable. They typically fail to hatch, or die within a few days of hatching with breathing, motor, and feeding issues. **Never pair Lilly × Lilly.** |
| **Cappuccino (CAPP/CAPP)** | ⚠️ Severe | Super Cappuccinos ("Melanistic" / "Mel") have reduced nostril size, breathing difficulty, and poor thriving. Breeding to produce supers is not recommended. |
| **Highway (HWY/HWY)** | ⚠️ Moderate | Documented complications in super form; use caution in pairing. |

Fire / BEL lines from different originators (Genetic Hypo, Pinky, GhostPax,
The Bugg Plug's Blizzard) have **not been proven compatible** — they may
represent convergent independent mutations rather than a single trait.

**Sources:**
[LM Reptiles — Cappuccino Guide](https://lmreptiles.com/fg-pt2-capps/);
[AC Reptiles — Whiteout Gene](https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44);
[MorphMarket Morphpedia — Lilly White](https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/).

## The Breeder Ecosystem & Primary Sources

### Foundation research & documentation
- **[Lil Monsters Reptiles](https://lmreptiles.com/fg-overview/)** (Anthony & Jessica Vasquez) — Foundation Genetics project. The most rigorous free genetics resource in the hobby.
- **[Geckological](https://www.instagram.com/geckological/)** (Tom Favazza) — Co-author of Foundation Genetics; book in development.

### Major breeders with named lines or discovered traits
- **[AC Reptiles](https://acreptiles.com/)** (Anthony Caponetto) — Whiteout, Harry (Furry), C2 Cream, Marble lines.
- **[Pangea Reptile](https://www.pangeareptile.com/)** (Matt Parks) — Betty White, XXX designation, Patient Zero piebald. One of the largest commercial operations.
- **Reptile City Korea** (Donald Hendrickson) — Cappuccino discovery.
- **Lilly Exotics** (UK) — Lilly White discovery.
- **[Altitude Exotics](https://www.altitudeexotics.com/)** — Axanthic line; first Lucy (Lilly × Axanthic).
- **Gecko Haven** — Sable (Rialto line).
- **Northern Gecko** (Mark Orfus) — Foundation Genetics contributor.

### Reference databases
- **[ReptiDex Genetics Library](https://reptidex.com/genetics/crested-gecko)** — Most organized allele database.
- **[MorphMarket Morphpedia](https://www.morphmarket.com/morphpedia/crested-geckos/)** — De facto commerce-side reference.

### Foundational books
- Repashy, Fast & de Vosjoli, *Rhacodactylus: The Complete Guide* (2003)
- Hamper, *Crested Geckos in Captivity* (2003)

## What's Still Unknown

Crested gecko genetics is an active research area. Genuine open questions:

- **No crested gecko morph has been sequenced at the DNA level.** All
  identification is phenotypic and breeding-proven.
- Whether Fire / BEL lines from different originators are genetically
  compatible or convergent independent mutations.
- Whether Marbling is a distinct trait or a modifier of existing traits.
- Whether the Furry / "Harry" trait is single-gene or polygenic.
- The full dominance range of Phantom, which appears to act with varying
  strength (suggesting polygenic modifiers layered on top of the single
  recessive).
- Whether Super Cappuccino health issues are intrinsic to the allele or
  can be reduced through outbreeding and better husbandry.

---

## FAQ: Common Questions About Crested Gecko Genetics

**Q: Are crested geckos polymorphic?**
Yes, but not in the old hobby sense. Crested geckos are **fixed polymorphic**,
meaning multiple wild-type phenotypes coexist in the wild population. This
does *not* mean traits are random or unpredictable — individual traits still
follow inheritance patterns. [Source](https://lmreptiles.com/foundation-genetics/)

**Q: Is there an albino crested gecko?**
No. No true albino (lacking melanin) crested gecko has been produced as of
2026. Axanthic (lacking yellow/red pigment) exists and is sometimes confused
with albinism.

**Q: Why can't you breed Lilly White × Lilly White?**
The homozygous form (two copies of the Lilly gene) is a non-viable leucistic
animal. They either fail to hatch or die within days of hatching. Always
pair Lilly White to non-Lilly White.
[Source](https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/)

**Q: What's the difference between Lilly White and Whiteout?**
Both produce white coloration, but Lilly White has a lethal super form
while Whiteout's homozygous form is healthy and freely breedable. Anthony
Caponetto of AC Reptiles argues both belong in serious collections for
different reasons. [Source](https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44)

**Q: Is Cappuccino the same as Melanistic?**
Melanistic is the *super form* (homozygous form) of Cappuccino. A
"Melanistic Crested Gecko" is genetically a Super Cappuccino and typically
has the health concerns associated with that genotype.
[Source](https://lmreptiles.com/fg-pt2-capps/)

**Q: Are Bicolor and Patternless separate morphs from Phantom?**
No. Both Bicolor and Patternless are phenotypic expressions of the Phantom
trait acting on different background trait combinations. This was one of
the key findings of the Foundation Genetics project.
[Source](https://lmreptiles.com/fg-findingphantom/)
