# Crested Gecko App Data Model

> **Purpose:** The database schema and data structures for a crested gecko
> app built on Foundation Genetics consensus. Covers traits, animals,
> pairings, and breeding predictions.
>
> **Format:** Presented as TypeScript types (most readable) with matching
> JSON Schema and SQL-style examples where helpful.
>
> **Intended use:** Drop into a Supabase / Postgres / Prisma project, or
> adapt for whatever stack you build on.

## The core insight

This is the single most important design decision for the app:

> **Traits are the primitive. Morphs are derived descriptions of trait stacks.**

This is the opposite of how most existing crested gecko databases are
built. MorphMarket treats "Tricolor" as a tag; your app should treat it
as the computed result of `base_color=black + white_pattern=yes +
orange_pattern=yes + harlequin=yes`.

Why this matters: lineage-tracking becomes accurate, breeding predictions
become mathematically correct, and morph names become searchable labels
on top of a proper genetic foundation.

---

## 1. Trait definitions

### TypeScript

```typescript
/**
 * The five dominance categories per Foundation Genetics.
 */
export type DominanceType =
  | 'fixed_dominant'       // Present in all members; cannot breed out (Tiger)
  | 'dominant'             // One copy = two copies (Dalmatian, Pinstripe)
  | 'incomplete_dominant'  // Het and hzg differ; hzg = "super" form
  | 'recessive'            // Needs two copies to express
  | 'codominant'           // Rare; both alleles express simultaneously
  | 'polygenic'            // Multiple genes contribute; not single-locus
  | 'unconfirmed';         // Inheritance not yet proven

/**
 * Health-risk classification for homozygous pairings.
 */
export type RiskLevel =
  | 'none'
  | 'moderate'    // Known complications but often viable
  | 'severe'      // Significant health concerns; breeding not recommended
  | 'lethal'      // Non-viable; never pair
  | 'unknown';    // Insufficient data

/**
 * Categories for UI filtering and organization.
 */
export type TraitCategory =
  | 'base_color'
  | 'pattern_structure'
  | 'pattern_color'
  | 'modifier'
  | 'structural'
  | 'independent_trait'; // e.g., blush, kneecaps, fringe

/**
 * A single genetic trait.
 */
export interface Trait {
  id: string;                      // slug: "lilly_white", "cappuccino"
  name: string;                    // "Lilly White"
  alternate_names?: string[];      // ["Lily White"] for search tolerance
  category: TraitCategory;

  dominance: DominanceType;
  locus: string;                   // Gene locus identifier (see locus notes)
  allele_notation?: string;        // "L+l" or "L" per Foundation Genetics
  super_allele_notation?: string;  // "L/L"

  // Super (homozygous) form
  has_super_form: boolean;
  super_form_name?: string;        // "Super Lilly White" / "Black Eyed Leucistic"
  super_health_risk: RiskLevel;
  super_risk_notes?: string;

  // Identification
  description: string;
  identification_markers: string[];  // ["white dorsal stripe", "raised lateral scales"]
  het_markers?: string[];           // Visible signs in heterozygous form, if any

  // Provenance
  originator?: string;              // "Lilly Exotics (UK)"
  first_produced_year?: number;
  proven_by?: string;               // Attribution for breeding proof
  proven_year?: number;

  // Relationships
  allelic_with?: string[];          // Other trait IDs at same locus
  epistatic_requirements?: string[]; // Traits required for expression (Snowflake needs WP)
  antagonisms?: string[];           // Traits that suppress this one

  // Sources (for citation & AI)
  primary_sources: SourceReference[];

  // Metadata
  confirmed: boolean;               // Has the inheritance been breeding-proven?
  last_reviewed: string;            // ISO date of last source review
}

export interface SourceReference {
  name: string;
  url: string;
  type: 'research' | 'database' | 'breeder_page' | 'book' | 'community';
}
```

### Example trait records

```typescript
export const TRAITS: Trait[] = [
  {
    id: 'lilly_white',
    name: 'Lilly White',
    alternate_names: ['Lily White'],
    category: 'modifier',
    dominance: 'incomplete_dominant',
    locus: 'L',
    allele_notation: 'L+l',
    super_allele_notation: 'L/L',
    has_super_form: true,
    super_form_name: 'Super Lilly White',
    super_health_risk: 'lethal',
    super_risk_notes:
      'Super Lilly White is non-viable. Offspring fail to hatch or die ' +
      'within days due to extreme melanin reduction affecting breathing, ' +
      'motor control, and feeding. Never pair Lilly White x Lilly White.',
    description:
      'Incomplete dominant leucistic trait producing white coloration ' +
      'with reduced pattern. White coloration typically expands as the ' +
      'animal matures.',
    identification_markers: [
      'white dorsal stripe (typically thick)',
      'stacked lateral scales near belly',
      'white tail in hatchlings',
      'raised yellow lateral scales within white areas',
    ],
    het_markers: [
      'velvet-textured skin (distinct from typical crested gecko feel)',
    ],
    originator: 'Lilly Exotics (UK)',
    first_produced_year: 2010,
    proven_by: 'Lilly Exotics',
    proven_year: 2012,
    primary_sources: [
      {
        name: 'MorphMarket Morphpedia — Lilly White',
        url: 'https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/',
        type: 'database',
      },
      {
        name: 'Foundation Genetics Part 2.1',
        url: 'https://lmreptiles.com/fg-pt2-1/',
        type: 'research',
      },
    ],
    confirmed: true,
    last_reviewed: '2026-04-17',
  },

  {
    id: 'cappuccino',
    name: 'Cappuccino',
    category: 'modifier',
    dominance: 'incomplete_dominant',
    locus: 'SABLE_COMPLEX',
    allele_notation: 'CAPP+ca',
    super_allele_notation: 'CAPP/CAPP',
    has_super_form: true,
    super_form_name: 'Super Cappuccino (Melanistic)',
    super_health_risk: 'severe',
    super_risk_notes:
      'Super Cappuccinos have reduced nostril size causing breathing ' +
      'difficulties, and poor overall thriving. Breeding specifically to ' +
      'produce supers is not recommended. Lower incubation temperatures ' +
      '(69-71F) reduce but do not eliminate structural issues.',
    description:
      'Incomplete dominant trait producing lighter tan / coffee ' +
      'coloration. Allelic with Sable and Highway at the same locus.',
    identification_markers: [
      'Y-shape at base of tail',
      'white flecks or splotching on lower spine/tail',
      'reduced or absent lateral pattern',
      'bright sharp white on tail base (hatchling)',
      'darker tail tip (hatchling)',
    ],
    originator: 'Reptile City Korea (Donald Hendrickson)',
    first_produced_year: 2020,
    proven_by: 'Reptile City Korea',
    proven_year: 2021,
    allelic_with: ['sable', 'highway'],
    primary_sources: [
      {
        name: 'LM Reptiles Cappuccino White Paper',
        url: 'https://lmreptiles.com/fg-pt2-capps/',
        type: 'research',
      },
    ],
    confirmed: true,
    last_reviewed: '2026-04-17',
  },

  {
    id: 'phantom',
    name: 'Phantom',
    category: 'modifier',
    dominance: 'recessive',
    locus: 'PH',
    allele_notation: 'PH+ph',
    has_super_form: false,  // Recessive; homozygous IS the visual form
    super_health_risk: 'none',
    description:
      'Simple recessive trait adding melanin and suppressing pattern. ' +
      'Produces Bicolor, Patternless, Buckskin, Charcoal, and Cream ' +
      'phenotypes depending on base color and pattern background. ' +
      'Loses dominance near tail base and on laterals.',
    identification_markers: [
      'darkened xanthophore layer',
      'suppressed dorsal pattern',
      'blended melanin in yellow-base animals',
      'base color visible through pattern on neck/head',
    ],
    het_markers: [
      'subtle dorsal darkening (unreliable)',
      'headstamp patterning (unreliable)',
    ],
    primary_sources: [
      {
        name: 'LM Reptiles — Finding Phantom',
        url: 'https://lmreptiles.com/fg-findingphantom/',
        type: 'research',
      },
    ],
    confirmed: true,
    last_reviewed: '2026-04-17',
  },

  {
    id: 'dalmatian',
    name: 'Dalmatian',
    category: 'pattern_structure',
    dominance: 'dominant',
    locus: 'DAL',
    allele_notation: 'DAL+dal',
    super_allele_notation: 'DAL/DAL',
    has_super_form: true,
    super_form_name: 'Super Dalmatian',
    super_health_risk: 'none',
    description:
      'Dominant trait producing black spotting. One copy = visible ' +
      'Dalmatian (hets pass 50%); two copies = heavier spotting (hzg ' +
      'pass 100%). Spot development continues with age.',
    identification_markers: [
      'black spots on body',
      'hatchlings may have few spots; gain more by ~25g',
    ],
    primary_sources: [
      {
        name: 'Foundation Genetics Part 1',
        url: 'https://lmreptiles.com/foundation-genetics/',
        type: 'research',
      },
    ],
    confirmed: true,
    last_reviewed: '2026-04-17',
  },

  // ... continue with all 30+ traits
];
```

### Locus notes

The locus IDs matter because some traits share loci (are allelic). Use
these:

| Locus | Traits | Notes |
|-------|--------|-------|
| `SABLE_COMPLEX` | Cappuccino, Sable, Highway | Three alleles at one locus |
| `L` | Lilly White | |
| `WO` | Whiteout | Distinct from Lilly |
| `PH` | Phantom | |
| `AX` | Axanthic | |
| `HQ` | Harlequin | |
| `PIN` | Pinstripe | |
| `DAL` | Dalmatian | |
| `TIG` | Tiger | Fixed dominant; always present |
| `EB` | Empty Back | |
| `FIRE` | Fire / BEL | Multiple lines, compatibility unconfirmed |
| `BASE_BLACK` | Black Base | |
| `BASE_RED` | Red Base | |
| `BASE_YELLOW` | Yellow Base | |
| `WP` | White Pattern | Polygenic but modeled at single locus for UI |
| `OP` | Orange Pattern | Polygenic but modeled at single locus for UI |
| `SF` | Snowflake | Epistatic to WP |
| `PIX` | Pixel | |
| `SS` | Softscale | |
| `CHOCHO` | ChoCho | |

---

## 2. Animal records

```typescript
/**
 * An individual gecko.
 */
export interface Animal {
  id: string;                      // UUID
  name?: string;                   // "Rogue" / breeder-given name
  species: 'correlophus_ciliatus'; // Future-proof for multi-species apps

  // Lineage
  sire_id?: string;                // Animal.id of father
  dam_id?: string;                 // Animal.id of mother

  // Genotype (the actual source of truth)
  genotype: AnimalGenotype;

  // Computed at query time from genotype
  // (don't store; derive from traits + combo_morph rules)
  phenotype_tags?: string[];       // For display/search: ["tricolor", "extreme_harlequin", "lilly_white"]

  // Metadata
  sex?: 'male' | 'female' | 'unknown';
  hatched_date?: string;           // ISO date
  weight_grams?: number;
  last_weighed?: string;           // ISO date
  status: 'active' | 'sold' | 'deceased' | 'loaned';
  notes?: string;

  // Commerce / tracking
  acquired_from?: string;          // Breeder name
  acquired_date?: string;
  acquired_price?: number;         // USD
  asking_price?: number;
  photos?: Photo[];

  // Breeder-side
  is_breeder: boolean;
  clutch_count?: number;
  owner_id: string;                // User.id
  created_at: string;
  updated_at: string;
}

/**
 * The genotype is the map of alleles at each locus.
 * Each locus has two alleles (one from each parent).
 * Each allele is either a trait ID, 'wild_type', or 'unknown'.
 */
export interface AnimalGenotype {
  [locus: string]: [Allele, Allele];
}

export type Allele =
  | string              // trait ID (e.g., "lilly_white", "phantom")
  | 'wild_type'         // the default / no-trait allele
  | 'unknown';          // inheritance unverified

/**
 * Example: A Lilly White Harlequin het Phantom
 */
const exampleGenotype: AnimalGenotype = {
  L: ['lilly_white', 'wild_type'],        // Het Lilly (visual Lilly)
  PH: ['phantom', 'wild_type'],           // Het Phantom (not visual)
  HQ: ['harlequin', 'wild_type'],         // Het Harlequin (visual)
  PIN: ['wild_type', 'wild_type'],        // No pinstripe
  DAL: ['wild_type', 'wild_type'],        // No dalmatian
  BASE_BLACK: ['black_base', 'black_base'], // Hzg black base
  WP: ['white_pattern', 'wild_type'],     // Has WP
  // ... etc for all loci
};

export interface Photo {
  url: string;
  caption?: string;
  fired_state?: 'fired_up' | 'fired_down';
  captured_date?: string;
}
```

### SQL equivalent (Postgres)

```sql
CREATE TABLE animals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT,
  sire_id UUID REFERENCES animals(id),
  dam_id UUID REFERENCES animals(id),

  -- Genotype stored as JSONB for flexibility
  -- Format: { "locus_id": ["allele1", "allele2"], ... }
  genotype JSONB NOT NULL DEFAULT '{}',

  sex TEXT CHECK (sex IN ('male', 'female', 'unknown')),
  hatched_date DATE,
  weight_grams NUMERIC(5,2),
  last_weighed DATE,
  status TEXT NOT NULL DEFAULT 'active',
  notes TEXT,

  acquired_from TEXT,
  acquired_date DATE,
  acquired_price NUMERIC(10,2),
  asking_price NUMERIC(10,2),

  is_breeder BOOLEAN NOT NULL DEFAULT false,

  owner_id UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_animals_owner ON animals(owner_id);
CREATE INDEX idx_animals_sire ON animals(sire_id);
CREATE INDEX idx_animals_dam ON animals(dam_id);

-- Query genotype for specific traits
CREATE INDEX idx_animals_genotype ON animals USING GIN (genotype);
```

---

## 3. Combo morph definitions (derived, not primitive)

Combo morphs are rules that match genotypes to named phenotypes.
Store them as pattern-match rules, not as primitive records.

```typescript
export interface ComboMorphRule {
  id: string;
  name: string;                    // "Tricolor"
  description: string;

  // A pattern match against an AnimalGenotype
  // Each condition specifies a locus and required allele pattern
  requirements: GenotypeRequirement[];

  // Anti-requirements (must NOT have)
  exclusions?: GenotypeRequirement[];

  // Display
  is_marketing_term: boolean;      // True for XXX, Moonglow, etc.
  marketing_term_notes?: string;   // "Pangea Reptile coined term"

  primary_sources: SourceReference[];
}

export interface GenotypeRequirement {
  locus: string;
  match: 'heterozygous' | 'homozygous' | 'present' | 'absent' | 'any_trait';
  allele?: string;                 // Specific trait if match requires it
}

// Example combo morph rules
export const COMBO_MORPHS: ComboMorphRule[] = [
  {
    id: 'tricolor',
    name: 'Tricolor',
    description:
      'Dark-base crested gecko displaying both White Pattern and Orange ' +
      'Pattern in roughly equal proportions, creating three ' +
      'distinguishable colors.',
    requirements: [
      { locus: 'BASE_BLACK', match: 'present' },
      { locus: 'WP', match: 'present', allele: 'white_pattern' },
      { locus: 'OP', match: 'present', allele: 'orange_pattern' },
      { locus: 'HQ', match: 'present', allele: 'harlequin' },
    ],
    is_marketing_term: false,
    primary_sources: [
      {
        name: 'Foundation Genetics Part 2.1',
        url: 'https://lmreptiles.com/fg-pt2-1/',
        type: 'research',
      },
    ],
  },

  {
    id: 'frappuccino',
    name: 'Frappuccino',
    description: 'Cappuccino + Lilly White combo morph.',
    requirements: [
      { locus: 'SABLE_COMPLEX', match: 'present', allele: 'cappuccino' },
      { locus: 'L', match: 'present', allele: 'lilly_white' },
    ],
    is_marketing_term: false,
    primary_sources: [
      {
        name: 'LM Reptiles Cappuccino Guide',
        url: 'https://lmreptiles.com/fg-pt2-capps/',
        type: 'research',
      },
    ],
  },

  {
    id: 'luwak',
    name: 'Luwak',
    description:
      'Compound heterozygote of Cappuccino and Sable. Produced by ' +
      'Cappuccino × Sable pairings — does NOT produce Super Cappuccino ' +
      'because these are distinct alleles at the same locus.',
    requirements: [
      { locus: 'SABLE_COMPLEX', match: 'heterozygous', allele: 'cappuccino' },
      { locus: 'SABLE_COMPLEX', match: 'heterozygous', allele: 'sable' },
    ],
    is_marketing_term: false,
    primary_sources: [
      {
        name: 'ReptiDex Crested Gecko Genetics',
        url: 'https://reptidex.com/genetics/crested-gecko',
        type: 'database',
      },
    ],
  },

  {
    id: 'extreme_harlequin',
    name: 'Extreme Harlequin',
    description:
      'Harlequin displaying 75%+ body pattern coverage, with pattern ' +
      'connecting dorsal and lateral regions.',
    requirements: [
      { locus: 'HQ', match: 'present', allele: 'harlequin' },
    ],
    // Note: extreme expression is polygenic and stacked; can't be purely
    // genetic-rule-defined. Flag for "high_expression" manually.
    is_marketing_term: false,
    primary_sources: [
      {
        name: 'Foundation Genetics Part 2.1',
        url: 'https://lmreptiles.com/fg-pt2-1/',
        type: 'research',
      },
    ],
  },

  {
    id: 'xxx',
    name: 'XXX',
    description:
      'Marketing term coined by Matt Parks at Pangea Reptile for ' +
      'phenotypically extreme Harlequin animals. NOT a proven genetic ' +
      'designation — XXX animals are not necessarily homozygous Harlequin.',
    requirements: [
      { locus: 'HQ', match: 'present', allele: 'harlequin' },
    ],
    is_marketing_term: true,
    marketing_term_notes:
      'XXX is a Pangea Reptile descriptor for extreme pattern expression. ' +
      'Use Extreme Harlequin as the scientifically accurate term.',
    primary_sources: [
      {
        name: 'Foundation Genetics Part 2.1',
        url: 'https://lmreptiles.com/fg-pt2-1/',
        type: 'research',
      },
    ],
  },

  {
    id: 'lucy',
    name: 'Lucy',
    description:
      'Visual combination of Lilly White and Axanthic. First produced ' +
      'by Altitude Exotics in 2019.',
    requirements: [
      { locus: 'L', match: 'present', allele: 'lilly_white' },
      { locus: 'AX', match: 'homozygous', allele: 'axanthic' },
    ],
    is_marketing_term: false,
    primary_sources: [
      {
        name: 'Tenny\'s Crested Geckos Morph Guide',
        url: 'https://tennyscrestedgeckos.com/crested-gecko-morphs/',
        type: 'breeder_page',
      },
    ],
  },

  // ... continue with all combo rules
];
```

---

## 4. Breeding calculator

The breeding calculator predicts offspring probabilities using Punnett
square math across multiple loci.

```typescript
export interface BreedingPrediction {
  parent_sire: Animal;
  parent_dam: Animal;

  // Per-locus predictions (independent loci)
  locus_predictions: LocusPrediction[];

  // Risk warnings
  warnings: BreedingWarning[];

  // Combined phenotype probabilities
  // (Cartesian product of locus predictions, filtered by combo morph rules)
  offspring_phenotypes: PhenotypePrediction[];
}

export interface LocusPrediction {
  locus: string;
  trait: string;
  outcomes: {
    genotype: [Allele, Allele];
    probability: number;            // 0.0 to 1.0
    phenotype_label: string;        // "Visual Lilly White", "Het Phantom", "Wild-type"
  }[];
}

export interface PhenotypePrediction {
  phenotype_description: string;   // "Lilly White Harlequin (het Phantom)"
  probability: number;
  matching_combo_morphs: string[]; // ["lilly_white", "harlequin"]
  health_risk?: RiskLevel;
}

export interface BreedingWarning {
  severity: 'info' | 'caution' | 'critical';
  code: string;
  message: string;
  source_url?: string;
}

/**
 * Example output for a Lilly White × Lilly White pairing
 */
const exampleWarning: BreedingWarning = {
  severity: 'critical',
  code: 'LILLY_X_LILLY_LETHAL',
  message:
    'This pairing will produce 25% Super Lilly White offspring, which ' +
    'is a lethal genotype. Super Lilly Whites fail to hatch or die ' +
    'within days of hatching. This pairing is not recommended under ' +
    'any circumstance. Consider pairing Lilly White to non-Lilly White.',
  source_url: 'https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/',
};
```

### Punnett square logic (simplified)

```typescript
function predictLocus(
  sireAlleles: [Allele, Allele],
  damAlleles: [Allele, Allele],
  trait: Trait,
): LocusPrediction {
  const combinations: [Allele, Allele][] = [];
  for (const s of sireAlleles) {
    for (const d of damAlleles) {
      combinations.push([s, d]);
    }
  }

  const counts = new Map<string, number>();
  for (const combo of combinations) {
    const key = JSON.stringify(combo.sort());
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  const outcomes = Array.from(counts.entries()).map(([key, count]) => {
    const genotype = JSON.parse(key) as [Allele, Allele];
    return {
      genotype,
      probability: count / combinations.length,
      phenotype_label: describeGenotype(genotype, trait),
    };
  });

  return { locus: trait.locus, trait: trait.id, outcomes };
}

function describeGenotype(genotype: [Allele, Allele], trait: Trait): string {
  const hasTrait = genotype.filter(a => a === trait.id).length;

  if (hasTrait === 0) return 'Wild-type';

  switch (trait.dominance) {
    case 'recessive':
      return hasTrait === 2
        ? `Visual ${trait.name}`
        : `Het ${trait.name}`;
    case 'incomplete_dominant':
      return hasTrait === 2
        ? trait.super_form_name ?? `Super ${trait.name}`
        : `${trait.name}`;
    case 'dominant':
    case 'fixed_dominant':
      return trait.name;
    default:
      return `${hasTrait} copy of ${trait.name}`;
  }
}
```

---

## 5. Health risk registry

A focused table of known risk pairings. Query this before confirming any
breeding plan.

```typescript
export const RISK_PAIRINGS: BreedingWarning[] = [
  {
    severity: 'critical',
    code: 'LILLY_X_LILLY_LETHAL',
    message:
      'Lilly White × Lilly White produces 25% Super Lilly White offspring, ' +
      'which is lethal. Never perform this pairing.',
    source_url: 'https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/',
  },
  {
    severity: 'critical',
    code: 'CAPP_X_CAPP_HEALTH',
    message:
      'Cappuccino × Cappuccino produces 25% Super Cappuccino (Melanistic) ' +
      'offspring with documented health issues including reduced nostril ' +
      'size and breathing difficulties. Breeding specifically for supers ' +
      'is not recommended.',
    source_url: 'https://lmreptiles.com/fg-pt2-capps/',
  },
  {
    severity: 'caution',
    code: 'HIGHWAY_X_HIGHWAY_HEALTH',
    message:
      'Highway × Highway produces 25% Super Highway offspring with ' +
      'documented complications. Use caution and research pairing outcomes ' +
      'before proceeding.',
    source_url: 'https://reptidex.com/genetics/crested-gecko',
  },
  {
    severity: 'caution',
    code: 'FIRE_LINE_INCOMPATIBILITY',
    message:
      'Fire/BEL/Blizzard lines from different originators (Genetic Hypo, ' +
      'Pinky, GhostPax, The Bugg Plug) have NOT been proven genetically ' +
      'compatible. Crossing lines may not produce BEL supers. Verify line ' +
      'compatibility before pairing.',
    source_url: 'https://reptidex.com/genetics/crested-gecko',
  },
];
```

---

## 6. Migration from MorphMarket-style tagging

If you're importing data from a system that uses flat morph tags
(MorphMarket, spreadsheets, older apps), here's the mapping strategy:

```typescript
/**
 * Maps a flat tag like "Lilly White Tricolor Harlequin" to a partial
 * genotype. The result is a best-guess — manual review is required for
 * confirmed records.
 */
export function tagToGenotype(tags: string[]): {
  genotype: Partial<AnimalGenotype>;
  confidence: 'high' | 'medium' | 'low';
  needs_review: string[];
} {
  const result: Partial<AnimalGenotype> = {};
  const needs_review: string[] = [];

  for (const tag of tags) {
    const normalized = tag.toLowerCase().replace(/\s+/g, '_');

    if (normalized === 'lilly_white' || normalized === 'lily_white') {
      result.L = ['lilly_white', 'wild_type']; // Assume het, flag for review
      needs_review.push('Lilly White detected — verify heterozygous vs homozygous');
    }

    if (normalized === 'cappuccino') {
      result.SABLE_COMPLEX = ['cappuccino', 'wild_type'];
      needs_review.push('Cappuccino detected — verify Cappuccino vs Sable vs Highway');
    }

    if (normalized === 'phantom') {
      // Ambiguous — could be het or visual
      needs_review.push('Phantom detected — verify visual (homozygous) vs het');
    }

    if (normalized === 'tricolor') {
      result.WP = ['white_pattern', 'wild_type'];
      result.OP = ['orange_pattern', 'wild_type'];
      // Don't infer harlequin yet - could be Tricolor flame
    }

    if (normalized === 'xxx' || normalized === 'extreme_harlequin') {
      result.HQ = ['harlequin', 'wild_type'];
      needs_review.push(
        'XXX / Extreme Harlequin is a descriptor, not proven homozygous HQ'
      );
    }

    // ... continue for all tag -> trait mappings
  }

  const confidence =
    needs_review.length === 0 ? 'high' :
    needs_review.length <= 2 ? 'medium' : 'low';

  return { genotype: result, confidence, needs_review };
}
```

---

## 7. Supabase-specific notes

If building on Supabase (which you're already connected to), here's the
recommended setup:

### Row-level security (RLS)

```sql
-- Animals are private to their owner
CREATE POLICY "Users can only see their own animals"
  ON animals FOR SELECT
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can only modify their own animals"
  ON animals FOR ALL
  USING (auth.uid() = owner_id);

-- Traits are public read
CREATE POLICY "Traits are publicly readable"
  ON traits FOR SELECT
  USING (true);
```

### Key storage keys (if using a client-side storage pattern)

```typescript
// User's collection
const collectionKey = `collection:${userId}`;

// Individual animal
const animalKey = `animal:${animalId}`;

// Pairing history
const pairingKey = `pairing:${pairingId}`;

// Cached breeding predictions
const predictionKey = `prediction:${sireId}:${damId}`;
```

---

## 8. What NOT to do

Anti-patterns I've seen in other crested gecko apps. Avoid these:

- **Don't store "morph" as a single string on the animal record.** If you
  later want to filter by trait, you're stuck doing string matching.
  Always store genotype at the trait level.

- **Don't ignore health risks in breeding UI.** If the calculator predicts
  any lethal or severe-risk offspring, the UI should surface this
  prominently — not bury it.

- **Don't treat marketing terms as genetics.** "XXX" should be a label on
  the animal, not a trait in the genotype. Flag these clearly.

- **Don't allow "super" to mean multiple things.** In genetics, "super"
  specifically means homozygous incomplete dominant. Not "extra high
  expression" or "really nice-looking." Enforce terminology in the UI.

- **Don't over-index on photo ID.** Photo-based morph identification is
  fundamentally unreliable for crested geckos because of fire-up/fire-down
  color shifts and the combinatorial nature of traits. It can suggest
  possibilities; it shouldn't make claims.

---

## Last updated

Document version 1.0, April 2026. Review when:
- New traits are added to the Foundation Genetics canon
- Supabase schema is migrated
- The app adds new features that require data model changes
