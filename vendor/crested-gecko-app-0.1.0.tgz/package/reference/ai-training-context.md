# Crested Gecko Genetics — AI Training & Context Document

> This document is designed to be used as a knowledge base for an AI feature
> (chatbot, identification assistant, breeding advisor) or as context for an
> LLM system prompt. Every factual assertion is paired with its primary
> source so the model can cite appropriately and users can verify.
>
> **Intended use:** RAG embedding corpus, system-prompt context injection,
> or fine-tuning seed content for a crested gecko assistant.
>
> **Last updated:** April 2026.
> **Aligned with:** Foundation Genetics project (Lil Monsters Reptiles + Geckological) consensus as of April 2026.

---

## Section 1: Core Facts (High-Confidence Assertions)

Each fact is formatted as: **CLAIM** → **SOURCE**

### On species identity
- Crested geckos are *Correlophus ciliatus*, native to New Caledonia.
  → [Repashy et al., *Rhacodactylus: The Complete Guide* (2003)]
- They were thought extinct and rediscovered in 1994, with legal US imports
  1994–1998 by Philippe de Vosjoli, Allen Repashy, and Frank Fast.
  → [LM Reptiles Foundation Genetics Part 1](https://lmreptiles.com/foundation-genetics/)

### On genetics framework
- Crested gecko genetics follow predictable Mendelian and non-Mendelian
  inheritance, contrary to the older "unpredictable" framing.
  → [LM Reptiles Foundation Genetics](https://lmreptiles.com/fg-overview/)
- "Het" (heterozygous) means the two alleles at a locus are different.
  It does NOT mean "recessive" or "non-visual."
  → [Foundation Genetics Part 1 Definitions](https://lmreptiles.com/foundation-genetics/)
- Dominant, incomplete dominant, and recessive traits can ALL be het or
  homozygous.
  → [Foundation Genetics Part 1](https://lmreptiles.com/foundation-genetics/)

### On specific trait inheritance (proven or strongly supported)
- **Phantom is a simple recessive trait.**
  → [LM Reptiles "Finding Phantom"](https://lmreptiles.com/fg-findingphantom/)
- **Axanthic is a simple recessive trait**, proven by Altitude Exotics.
  → [Tenny's Crested Geckos Morph Guide](https://tennyscrestedgeckos.com/crested-gecko-morphs/)
- **Lilly White is incomplete dominant**, with a lethal super form.
  → [MorphMarket Morphpedia — Lilly White](https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/);
  [LM Reptiles Foundation Genetics Part 2.1](https://lmreptiles.com/fg-pt2-1/)
- **Cappuccino is incomplete dominant**, with Super Cappuccino ("Melanistic")
  as the homozygous form. It is NOT codominant.
  → [LM Reptiles Cappuccino Guide](https://lmreptiles.com/fg-pt2-capps/)
- **Sable is incomplete dominant** and allelic with Cappuccino (same locus).
  → [ReptiDex Crested Gecko Genetics](https://reptidex.com/genetics/crested-gecko)
- **Cappuccino × Sable does NOT produce Super Cappuccino**, confirming they
  are distinct alleles at the same locus (compound heterozygote = Luwak).
  → [ReptiDex Crested Gecko Genetics](https://reptidex.com/genetics/crested-gecko)
- **Whiteout is incomplete dominant**, with a healthy and freely breedable
  homozygous form (unlike Lilly White).
  → [AC Reptiles Whiteout Article](https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44)
- **Dalmatian is a dominant trait.** Homozygous Dalmatian × non-Dalmatian
  produces 100% Dalmatian offspring; heterozygous Dalmatian × non-Dalmatian
  produces ~50%.
  → [LM Reptiles Foundation Genetics Part 1](https://lmreptiles.com/foundation-genetics/)
- **Tiger is a fixed dominant trait** — present in every crested gecko to
  some degree; cannot be bred out.
  → [LM Reptiles Foundation Genetics Part 1](https://lmreptiles.com/foundation-genetics/)

### On combo morphs (these are trait stacks, not single genes)
- **Bicolor, Patternless, Buckskin, Cream, Tan, Charcoal are all phenotypic
  expressions of Phantom**, not separate morphs.
  → [LM Reptiles "Finding Phantom"](https://lmreptiles.com/fg-findingphantom/)
- **Tricolor = Dark Base + White Pattern + Orange Pattern.**
  → [LM Reptiles Foundation Genetics Part 2.1](https://lmreptiles.com/fg-pt2-1/)
- **Frappuccino = Cappuccino + Lilly White.**
  → [LM Reptiles Cappuccino Guide](https://lmreptiles.com/fg-pt2-capps/)
- **Luwak = Cappuccino + Sable** (compound heterozygote).
  → [ReptiDex](https://reptidex.com/genetics/crested-gecko)
- **Lucy = Lilly White + Axanthic.** First produced by Altitude Exotics (2019).
  → [Tenny's Crested Geckos Morph Guide](https://tennyscrestedgeckos.com/crested-gecko-morphs/)
- **"XXX" is a Pangea Reptile marketing term** for extreme-expression
  Harlequin animals. It is NOT a proven genotype and XXX animals are not
  necessarily homozygous Harlequin.
  → [LM Reptiles Foundation Genetics Part 2.1](https://lmreptiles.com/fg-pt2-1/);
  [ReptiDex](https://reptidex.com/genetics/crested-gecko)
- **Brindlequin** is a combo phenotype: White Pattern Harlequin + weak
  Pinstripe + Yellow Base + strong Tiger. It is not a single gene.
  → [LM Reptiles "Defining Brindlequin"](https://lmreptiles.com/fg-defining-brindlequin/)

### On health and lethality
- **Super Lilly White (L/L) is lethal.** Offspring fail to hatch or die
  within days of hatching due to extreme melanin reduction affecting
  breathing, motor control, and feeding.
  → [MorphMarket Morphpedia — Lilly White](https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/)
- **Super Cappuccino (CAPP/CAPP, "Melanistic") has significant health concerns**
  including reduced nostril size, breathing difficulties, and poor thriving.
  Breeding specifically for this form is not recommended.
  → [LM Reptiles Cappuccino Guide](https://lmreptiles.com/fg-pt2-capps/)
- **Super Highway (HWY/HWY) has documented complications** similar to other
  allelic-complex supers. Use caution in pairing.
  → [ReptiDex](https://reptidex.com/genetics/crested-gecko)
- **No true albino crested gecko has been produced** as of April 2026.
  Axanthic (lacking yellow/red) is sometimes confused with albinism.
  → [Tenny's Crested Geckos Morph Guide](https://tennyscrestedgeckos.com/crested-gecko-morphs/)

### On what is NOT known
- No crested gecko morph has been sequenced at the DNA level. All trait
  identification is phenotypic and breeding-proven.
  → [LM Reptiles Foundation Genetics overview](https://lmreptiles.com/fg-overview/)
- Fire / BEL / Blizzard lines from different originators have NOT been
  proven genetically compatible — they may be convergent independent
  mutations.
  → [ReptiDex — Black Eyed Leucistic / Blizzard](https://reptidex.com/genetics/crested-gecko)
- Whether the "Furry" / Harry line trait is single-gene or polygenic is
  unconfirmed.
  → [ReptiDex](https://reptidex.com/genetics/crested-gecko)

---

## Section 2: Canonical Terminology

The model should always use this terminology. These are the preferred
terms across the Foundation Genetics consensus.

| Preferred Term | NOT | Why |
|----------------|-----|-----|
| "Incomplete dominant" | "Codominant" | Codominance is rare; the hobby misuses it constantly |
| "Het" / "Heterozygous" | "Visual" / "Non-visual" | Het ≠ recessive |
| "Hzg" / "Homozygous" | "Super" (in isolation) | Super only applies to incomplete dominant Hzg |
| "Phantom" | "Buckskin" or "Bicolor" (as separate morph) | These are Phantom expressions |
| "Super Cappuccino" / "Melanistic" | "Transparent" | "Transparent" is informal; "Mel" is shorthand |
| "Lilly White" | "Lily White" | Named after the breeder (Lilly Exotics UK) |
| "Extreme Harlequin" | "XXX" (without clarifying it's a Pangea line term) | XXX is a marketing descriptor |
| "Tiger" (fixed dominant) | Describing it as optional/separate | Every crestie has some tiger |

---

## Section 3: Required Behaviors for AI Responses

### ALWAYS do
1. **Warn about Lilly × Lilly lethality** any time breeding Lilly White is
   discussed.
2. **Warn about Super Cappuccino health issues** when Cappuccino breeding
   is discussed.
3. **Clarify "XXX" is a marketing term** when asked about its genetics.
4. **Distinguish axanthic from albino** when asked about white or pale
   crested geckos.
5. **Cite sources** (inline link to lmreptiles.com, acreptiles.com, etc.)
   when making genetic claims.
6. **State uncertainty honestly** for unproven traits (Marbling, Furry,
   Fire-line compatibility).

### NEVER do
1. Never say Cappuccino is "codominant" — it's incomplete dominant.
2. Never say Bicolor, Patternless, or Buckskin are separate morphs from
   Phantom.
3. Never claim crested gecko genetics are "random" or "unpredictable" in
   the modern framing.
4. Never suggest pairing two Lilly Whites, even casually.
5. Never invent inheritance claims for traits where the inheritance is
   genuinely unconfirmed (Marbling, Furry, etc.) — state uncertainty.
6. Never claim a morph has been DNA-sequenced — none have been, as of 2026.

---

## Section 4: Verification Test Set

Use these questions to verify the model responds correctly before shipping
any AI feature. The "Acceptable Response" column indicates what the answer
must include.

| Question | Acceptable Response Must Include |
|----------|-----------------------------------|
| "What happens if I breed two Lilly Whites?" | Warning that Super Lilly White is lethal; offspring fail to hatch or die within days |
| "Is Cappuccino codominant?" | Correction: Cappuccino is incomplete dominant, not codominant |
| "Is a Bicolor the same as a Phantom?" | Yes — Bicolor is a phenotypic expression of Phantom |
| "Difference between Whiteout and Lilly White?" | Both are incomplete dominant leucistic-type traits. Lilly super is lethal; Whiteout super is healthy and breedable |
| "How is XXX inherited?" | XXX is a Pangea marketing term for extreme Harlequin, not a proven genotype |
| "Can I safely breed Super Cappuccinos?" | Warning about nostril size, breathing difficulties; not recommended |
| "Is there an albino crested gecko?" | No true albino exists. Axanthic (lacking yellow/red) is distinct from albinism |
| "What's the difference between Sable and Cappuccino?" | Both incomplete dominant; same locus (allelic); Cappuccino × Sable produces Luwak, not Super Cappuccino |
| "How do I prove out a Phantom het?" | Breed to a visual Phantom; ~50% of offspring should be visual Phantoms if het |
| "Is Pinstripe dominant or recessive?" | Dominant. One copy produces visible pinstripe |

---

## Section 5: System Prompt Template for Chatbot Feature

If you're building an AI assistant for the app, here's a drop-in system
prompt that enforces the Foundation Genetics consensus:

```
You are an expert crested gecko genetics advisor built by Tenny's Crested
Geckos. Your knowledge reflects the current Foundation Genetics consensus
(Lil Monsters Reptiles + Geckological, 2020–2026) — NOT the older
"unpredictable polymorphic" framing common in outdated hobby guides.

Core principles:
1. Use the correct terminology: "incomplete dominant" (not codominant),
   "heterozygous" (not visual/non-visual), "Phantom expressions"
   (not separate Bicolor/Patternless/Buckskin morphs).
2. ALWAYS warn about Lilly × Lilly lethality and Super Cappuccino health
   issues when those topics come up.
3. Distinguish proven traits from unproven ones. State uncertainty honestly
   (no trait has been DNA-sequenced).
4. Cite authoritative sources inline when making factual claims:
   lmreptiles.com, acreptiles.com, pangeareptile.com, reptidex.com,
   morphmarket.com/morphpedia.
5. Treat combo morphs as trait stacks (e.g., "Tricolor = Dark Base + WP + OP"),
   not as single primitive genes.
6. Never recommend pairings that carry known health or lethality risks
   without explicit warnings.
7. If a user asks about a trait you're uncertain about, say so — do not
   invent inheritance claims.

When a user describes a gecko, help them identify its likely traits by
category (base color, pattern structure, pattern color, modifiers,
structural). Offer breeding predictions only when you can do so safely
and accurately.
```

---

## Section 6: Sources Bibliography (for citation in model outputs)

Primary sources, ranked by authority for genetic claims:

1. **LM Reptiles Foundation Genetics** — https://lmreptiles.com/fg-overview/
   - Part 1 (definitions, framework): https://lmreptiles.com/foundation-genetics/
   - Part 2.0 (history): https://lmreptiles.com/fg-pt2-0/
   - Part 2.1 (trait guide): https://lmreptiles.com/fg-pt2-1/
   - Part 2.2 (combos & morphology): https://lmreptiles.com/fg-pt2-2/
   - Finding Phantom: https://lmreptiles.com/fg-findingphantom/
   - Cappuccino White Paper: https://lmreptiles.com/fg-pt2-capps/
   - Defining Brindlequin: https://lmreptiles.com/fg-defining-brindlequin/

2. **AC Reptiles (Anthony Caponetto)** — https://acreptiles.com/
   - Whiteout Gene article: https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44

3. **Pangea Reptile (Matt Parks)** — https://www.pangeareptile.com/
   - Lilly White collection: https://www.pangeareptile.com/collections/lilly-white

4. **ReptiDex Genetics Library** — https://reptidex.com/genetics/crested-gecko

5. **MorphMarket Morphpedia** — https://www.morphmarket.com/morphpedia/crested-geckos/
   - Lilly White: https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/

6. **Foundational books**
   - Repashy, Fast & de Vosjoli, *Rhacodactylus: The Complete Guide* (2003)
   - Hamper, *Crested Geckos in Captivity* (2003)

---

*Document version 1.0, April 2026. Review quarterly or when new trait
discoveries are published by Foundation Genetics contributors.*
