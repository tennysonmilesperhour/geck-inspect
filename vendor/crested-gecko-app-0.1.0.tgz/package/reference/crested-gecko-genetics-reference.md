# Crested Gecko Genetics & Morphs — Expert Reference

> A synthesis of the current state-of-the-art understanding of crested gecko
> (*Correlophus ciliatus*) genetics, assembled from the most rigorous
> sources available as of 2026.

---

## 1. Framing: why the old hobby wisdom is wrong

For roughly 20 years, the crested gecko community accepted that their genetics
were "polymorphic and unpredictable." This was a placeholder, not a fact — it
meant "we haven't figured it out yet." The current leading work (Lil Monsters
Reptiles' **Foundation Genetics** project, in collaboration with Geckological,
Pangea, AC Reptiles, Northern Gecko, Reptile City Korea, and others) has
demonstrated that a growing number of crested gecko traits follow predictable
Mendelian and non-Mendelian inheritance patterns.

The hobby is mid-transition from **lineage-based breeding** ("my gecko's
grandpa was Betty White") to **trait-based breeding** ("my gecko is Het
Phantom, Hzg Pinstripe, carries Harlequin and White Pattern").

### Foundational terminology corrections

The single most-misused word in the hobby is "het." It does **not** mean
"recessive" or "non-visual." **Het just means the two alleles of a gene are
different from each other.** Dominant, incomplete dominant, and recessive
traits can all be het or homozygous.

- **Gene** — a section of DNA responsible for a heritable characteristic.
- **Allele** — a variant of a gene at a specific locus. Two alleles per gene,
  one from each parent.
- **Allelic** — two traits that occupy the same gene locus (e.g., Cappuccino
  and Sable are allelic).
- **Heterozygous (Het)** — the two alleles at a locus are different.
- **Homozygous (Hzg)** — the two alleles at a locus are identical.
- **Genotype** — the genetic code (what's on the DNA).
- **Phenotype** — the visible expression (what the animal looks like).
- **Epistasis** — when one gene controls whether another gene is expressed.
  *Very important in cresteds because most morphs are layered trait stacks.*

---

## 2. The five dominance categories

Every trait falls into one of these. This determines how it passes to offspring.

### 2.1 Fixed dominant / wild-type
Present in all members of the species, cannot be bred out.
- **Tiger** — every crested gecko has some tigering; ratio to other traits
  determines whether it's subtle freckling or heavy brindling.
- **Black Base** (fixed dominant in most wild-type animals)

### 2.2 Dominant
One copy produces the same phenotype as two copies.
- **Dalmatian** is the classic example. If one parent is Hzg Dalmatian, 100%
  of babies get spots; if Het, 50%.
- **Pinstripe** behaves as dominant (though Hzg may produce stronger/more
  complete pins).
- **Hypo** is dominant over melanin.

### 2.3 Incomplete dominant (the "super" makers)
One copy = visible trait; two copies = a distinct "super" form.
- **Lilly White** (super is lethal)
- **Cappuccino** (super = Super Cappuccino / "Mel", has health issues)
- **Sable** (super = Super Sable, healthy)
- **Highway** (super has moderate health concerns)
- **Empty Back** (super = Super Empty Back, healthy)
- **Whiteout / Whitewall** (super is healthy and breedable)
- **Softscale** (super has enhanced matte effect)
- **Fire** (super = Black Eyed Leucistic / Blizzard)

### 2.4 Recessive
Needs two copies to be visible. Het animals may show markers but don't
express the trait.
- **Phantom** — the most widespread and most misunderstood trait in the hobby
- **Axanthic** — proven recessive
- **Red Base** — strongly suspected recessive; blush on cheeks is a reliable
  het marker
- **ChoCho** — simple recessive
- **Pixel** — recessive pattern disruptor
- **Superstripe** — appears recessive

### 2.5 Codominant
Extremely rare in all animals. The crested gecko community chronically misuses
this word. True codominance means two dominant alleles both express
simultaneously without blending, producing localized regions of each trait
(think blood types). Most traits called "codominant" in the hobby are actually
incomplete dominant.

---

## 3. The layered trait model

Crested gecko phenotypes are built like Photoshop layers. Understanding this
is the key to reading a gecko correctly.

1. **Base color** — Black, Red, Yellow, Tangerine (melanin-driven)
2. **Pattern structure** — Harlequin, Flame, Pinstripe, Tiger, Dalmatian
3. **Pattern color** — White Pattern (WP) or Orange Pattern (OP)
4. **Modifier** — Phantom, Hypo, Cappuccino, Lilly White, Axanthic
5. **Structural** — Softscale, Furry, crest/scale traits

A **Tricolor Extreme Harlequin** = Black Base + Harlequin (heavy expression)
+ WP + OP + strong tiger breaks. No single gene produces this. Five trait
stacks produce it together.

---

## 4. The major traits, by category

### 4.1 Base colors

| Trait | Inheritance | Notes |
|-------|------------|-------|
| Black Base | Fixed dominant | Most prevalent; the darkest melanin production |
| Red Base | Recessive (suspected) | Blush on cheeks is a reliable het marker |
| Yellow Base | Dominant/co-dominant | Naturally hypo-melanistic |
| Tangerine | Modifier | Pushes coloration toward orange/peach; combos with WP make pink/bubblegum |

### 4.2 Pattern structure

| Trait | Inheritance | Notes |
|-------|------------|-------|
| Tiger | Fixed dominant (wild-type) | Pattern modifier; breaks horizontal pattern into vertical bars |
| Harlequin | Incomplete dominant (HQ) + polygenic | Concentrates dorsal pattern; homozygous = "XXX"/Extreme Harlequin phenotype |
| Flame | Polygenic | Ancestral form of harlequin; restricted to dorsum |
| Pinstripe | Dominant | Raised scales along dorsal ridge |
| Dalmatian | Dominant | Black spotting; homozygous adds density |
| Empty Back | Incomplete dominant | Clears dorsal pattern |

### 4.3 Pattern color

| Trait | Inheritance | Notes |
|-------|------------|-------|
| White Pattern (WP) | Polygenic | Primary pattern color; base for Snowflake expression |
| Orange Pattern (OP) | Polygenic | Secondary pattern color; WP + OP = Tricolor |
| Snowflake | Epistatic to WP | Requires WP to express |

### 4.4 Color modifiers (the "designer" morphs)

| Trait | Inheritance | Originator | Notes |
|-------|------------|-----------|-------|
| Phantom | Recessive | (found in many collections) | Adds melanin; produces bi-color, patternless, buckskin, cream, charcoal as expression variants |
| Hypo | Dominant | — | Reduces melanin; creates Lavender (+ Black), Pink (+ Red), Cream/C2 (+ Yellow) |
| Lilly White | Incomplete dominant | Lilly Exotics (UK), ~2010 | **Super is lethal.** Never pair Lilly × Lilly |
| Cappuccino | Incomplete dominant | Reptile City Korea, ~2020 | Super = Melanistic with health issues |
| Sable | Incomplete dominant | Gecko Haven | Allelic with Cappuccino |
| Highway | Incomplete dominant | — | Third allele in Sable/Cappuccino complex |
| Axanthic | Recessive | Altitude Exotics | Removes yellow/red; produces black & white animals |
| Whiteout / Whitewall | Incomplete dominant | AC Reptiles (Anthony Caponetto) | **Super is healthy and breedable** — strategic advantage over Lilly |
| Fire | Incomplete dominant | Multiple lines (not all compatible) | Super = Black Eyed Leucistic / Blizzard |
| ChoCho | Recessive | — | Hatches bright orange, darkens with age |

### 4.5 Structural

| Trait | Inheritance | Notes |
|-------|------------|-------|
| Softscale | Incomplete dominant | Matte, smooth scales |
| Furry | Unconfirmed (polygenic suspected) | Enhanced scale texture, AC Reptiles' "Harry" line |
| Marbling | Early-stage | Best expressed on Lilly White background |
| Pixel | Recessive | Fractures patterns into pixelated appearance |

---

## 5. Key combo morphs (marketing names → genetic recipes)

These are **named descriptions of trait stacks**, not single genes.

| Named Morph | Genetic Recipe |
|-------------|----------------|
| Tricolor | Dark Base + WP + OP |
| Halloween | Black Base + OP |
| Extreme Harlequin / XXX | Harlequin stacked to near-homozygous expression (Matt Parks, Pangea) |
| Brindlequin | WP Harlequin + weaker Pinstripe + Yellow Base + strong Tiger |
| Frappuccino | Cappuccino + Lilly White |
| Phantom Frappuccino | Cappuccino + Lilly White + Phantom |
| Luwak | Cappuccino + Sable (compound het) |
| Lavender | Hypo + Black Base |
| Pink | Hypo + Red Base |
| Cream / C2 | Hypo + Yellow Base (AC Reptiles line) |
| Creamsicle | Yellow Base + Hypo and/or Tangerine |
| Lucy | Lilly White + Axanthic (first produced by Altitude Exotics, ~2019) |
| Patternless | Phantom acting on a low-pattern animal |
| Charcoal / OG Black / Bi-color | Phantom expression variants (not separate morphs) |

**Important:** "XXX" is a Matt Parks / Pangea marketing term for extreme
harlequin animals — it does **not** mean the animal is homozygous Harlequin
in a proven genetic sense.

---

## 6. Health-risk alleles (build these into any breeding logic)

| Allele | Risk Level | Description |
|--------|-----------|-------------|
| Lilly White (L/L) | **Lethal** | Super form non-viable; never pair Lilly × Lilly |
| Cappuccino (CAPP/CAPP) | Severe | Super "Mel" has reduced nostrils, breathing issues, poor thriving |
| Highway (HWY/HWY) | Moderate | Documented complications in super form |
| Fire / BEL lines | Unknown | Multiple independent lines exist; compatibility not proven |

---

## 7. The breeder ecosystem

### Primary genetics research / documentation
- **Lil Monsters Reptiles** (Anthony & Jessica Vasquez) — Foundation Genetics project. The most rigorous free resource. https://lmreptiles.com/fg-overview/
- **Geckological** (Tom Favazza) — Co-author of Foundation Genetics; book in development.

### Major breeders with named lines/traits
- **AC Reptiles** (Anthony Caponetto) — Whiteout, Harry (Furry), C2, Marble lines. https://acreptiles.com
- **Pangea Reptile** (Matt Parks) — Betty White line, XXX designation, Patient Zero piebald, one of the largest commercial operations. https://www.pangeareptile.com
- **Reptile City Korea** (Donald Hendrickson) — Cappuccino discovery.
- **Lilly Exotics** (UK) — Lilly White discovery.
- **Altitude Exotics** — Axanthic line; first Lucy.
- **Gecko Haven** — Sable (Rialto line).
- **Northern Gecko** (Mark Orfus) — Foundation Genetics contributor.

### Reference databases
- **ReptiDex** — Commercial breeding software with the most organized allele database. https://reptidex.com/genetics/crested-gecko
- **MorphMarket Morphpedia** — De facto commerce-side reference. https://www.morphmarket.com/morphpedia/crested-geckos/
- **MorphMarket Community** — Active discussion and Q&A. https://community.morphmarket.com

### Books
- Repashy, Fast & de Vosjoli, *Rhacodactylus: The Complete Guide* (2003) — foundational
- Hamper, *Crested Geckos in Captivity* (2003)
- de Vosjoli & Vasquez, *Gargoyle Geckos* (applicable framework)

---

## 8. Practical implications for the gecko app

If this reference is informing app design, the core modeling primitives are:

### Trait model
Each trait needs:
- Name
- Inheritance type (fixed dominant / dominant / incomplete dominant / recessive / polygenic / allelic-complex-member)
- Locus identifier (so allelic complexes can be represented — e.g., Cappuccino/Sable/Highway share a locus)
- Has-super flag + super description
- Homozygous-risk flag + risk level
- Category (base / pattern-structure / pattern-color / modifier / structural)
- Dependencies / epistatic relationships (e.g., Snowflake requires WP)
- Antagonisms (e.g., Harlequin vs Empty Back)

### Gecko model
Each animal has:
- 2 alleles per trait locus (het/hzg/absent)
- Lineage links (sire, dam)
- Visual expression notes (stacking level)
- Phenotype description (derived from allele stack + polygenic expression level)

### Calculator
A punnett-table based pairing predictor that:
- Multiplies probabilities across independent loci
- Warns on lethal pairings (L × L)
- Warns on ethical concerns (CAPP × CAPP, HWY × HWY)
- Accounts for allelic complexes (Cappuccino × Sable cannot produce Super Cappuccino)

### Pricing/market context (for benchmarks)
(From `tennyscrestedgeckos.com` reference):
- Entry morphs: ~$50–250
- Mid-range: ~$120–450
- High-end: ~$400–800+
- Lilly White: ~$250–1200
- Axanthic: up to ~$2,500
- Market average: ~$350

---

## 9. Open research questions (where the hobby genuinely doesn't know yet)

- Full sequencing / molecular identification of any crested gecko morph allele
  (none have been genotyped at the DNA level — all identification is
  phenotypic / breeding-proven).
- Whether Fire lines from different originators (Genetic Hypo, Pinky,
  GhostPax, The Bugg Plug's Blizzard) are compatible or represent convergent
  independent mutations.
- Whether Marbling is a distinct trait or related to existing traits.
- Whether Furry (Harry line) is a single-gene trait or polygenic.
- Whether Cappuccino breeding fertility issues are genetic or incidental.
- The full dominance range of Phantom (it appears to act with varying
  strength, suggesting polygenic modifiers on top of the single recessive).

---

## 10. Sources cited

1. Lil Monsters Reptiles — Foundation Genetics Part 1: https://lmreptiles.com/foundation-genetics/
2. Lil Monsters Reptiles — Foundation Genetics Part 2.0: https://lmreptiles.com/fg-pt2-0/
3. Lil Monsters Reptiles — Foundation Genetics Part 2.1: https://lmreptiles.com/fg-pt2-1/
4. Lil Monsters Reptiles — Foundation Genetics Part 2.2: https://lmreptiles.com/fg-pt2-2/
5. Lil Monsters Reptiles — Cappuccino Guide: https://lmreptiles.com/fg-pt2-capps/
6. Lil Monsters Reptiles — Finding Phantom: https://lmreptiles.com/fg-findingphantom/
7. Lil Monsters Reptiles — Defining Brindlequin: https://lmreptiles.com/fg-defining-brindlequin/
8. AC Reptiles — Whiteout Gene Guide: https://acreptiles.com/new_store/index.php?dispatch=pages.view&page_id=44
9. Pangea Reptile — Lilly White reference: https://www.pangeareptile.com/collections/lilly-white
10. ReptiDex — Crested Gecko Genetics: https://reptidex.com/genetics/crested-gecko
11. MorphMarket Morphpedia — Lilly White: https://www.morphmarket.com/morphpedia/crested-geckos/lilly-white/
12. Zen Habitats — Crested Gecko Morph Guide: https://www.zenhabitats.com/blogs/reptile-care-sheets-resources/crested-gecko-guide-to-morphs-colors-and-traits
13. Moon Valley Reptiles — Crested Gecko Morphs: https://www.moonvalleyreptiles.com/crested-geckos/morphs
14. Moon Valley Reptiles — Crested Gecko Genetics: https://www.moonvalleyreptiles.com/crested-geckos/morphs/crested-gecko-genetics
15. Tenny's Crested Geckos — Morph Guide: https://tennyscrestedgeckos.com/crested-gecko-morphs/
16. Gecko Time — Introduction to Crested Gecko Morphs: https://geckotime.com/an-introduction-to-crested-gecko-morphs/

---

*Document compiled April 2026. Crested gecko genetics remains an active
research area — this document will need updating as new traits are proven and
as molecular techniques begin to be applied to the species.*
