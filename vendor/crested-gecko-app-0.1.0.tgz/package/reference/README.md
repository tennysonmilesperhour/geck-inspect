# Crested Gecko Genetics — Project Documents (Complete Set)

Eight documents supporting the crested gecko project (tennyscrestedgeckos.com
+ app). Each has a specific purpose and a specific audience.

## The eight files

### Reference & background
1. **`crested-gecko-genetics-reference.md`** — The master reference. Full
   Foundation Genetics synthesis. Your personal/internal source of truth.

### Content (for the live website)
2. **`foundation-genetics-section.md`** — A ready-to-publish new section for
   the live morph guide page. Written for traditional + AI SEO.
3. **`wordpress-edits.md`** — Fourteen specific before/after edits to fix
   the existing morph guide page without a full rewrite.

### Infrastructure (SEO & structure)
4. **`schema-markup.md`** — JSON-LD schema (Article, FAQPage, BreadcrumbList,
   DefinedTermSet) that AI engines parse directly. Copy-paste into
   WordPress head.

### Strategy & audit
5. **`morph-tag-audit.md`** — Audit of current live content vs. Foundation
   Genetics consensus. Priority-ordered corrections. Also contains the
   recommended morph tag taxonomy for the app.

### App / backend
6. **`app-data-model.md`** — TypeScript types, SQL schema, combo-morph
   rules, breeding calculator logic, risk pairing registry. Production-
   ready data model.

### AI features
7. **`ai-training-context.md`** — Knowledge base for embedding / RAG /
   system prompts. Canonical facts, each with source.
8. **`ai-system-prompt-and-eval.md`** — Production system prompt + full
   evaluation suite (39 test cases across 8 categories) to verify any
   AI feature before launch.

## Recommended implementation order

### Phase 1: Immediate fixes (30 minutes, no risk)
Small changes, immediate SEO benefit.

1. Add the "Last Updated" banner to the morph guide page
   (Edit 14 in `wordpress-edits.md`)
2. Update the page title and meta description (Edit 13)
3. Paste the schema markup combined block (from `schema-markup.md`)
   into the page head

### Phase 2: Priority factual corrections (1-2 hours)
Fix the wrong claims before adding new content. Internal contradictions
hurt AI SEO more than missing content does.

4. Apply Edits 1-6 in `wordpress-edits.md`:
   - Cappuccino codominant → incomplete dominant
   - Patternless/Buckskin → Phantom expressions
   - Add Lilly lethality warning
   - Update Dalmatian inheritance
   - Rewrite Phantom section
   - Replace Moonglow entry

### Phase 3: Content expansion (2-4 hours)
Add the new material.

5. Add the Foundation Genetics primer (Edit 7)
6. Add the new trait sections (Edits 8-11) — Whiteout, Sable, Highway,
   Softscale, Snowflake, Pixel, Fire/Blizzard, ChoCho, Empty Back, Luwak,
   Frappuccino
7. Update the Extreme Harlequin section (Edit 12)
8. Expand the Axanthic section (Edit 10)

### Phase 4: App build (ongoing)
When building the app:

9. Set up the database schema from `app-data-model.md`
10. Seed the trait table from `ai-training-context.md`
11. Build the breeding calculator using the Punnett-square logic
12. Enforce risk warnings via the `RISK_PAIRINGS` registry

### Phase 5: AI features (before any AI feature ships)
13. Use the system prompt from `ai-system-prompt-and-eval.md`
14. Run the full 39-test evaluation suite
15. Do not ship until Category B (breeding safety) passes 100%

## After publishing

1. Submit updated URL via Google Search Console → URL Inspection →
   Request Indexing
2. Submit via Bing Webmaster Tools
3. Validate schema with https://search.google.com/test/rich-results
4. Monitor over 2-4 weeks for FAQ rich snippets, "People also ask"
   inclusions, and AI engine citations

## Maintenance cadence

- **Weekly:** Review user questions (if logged) for knowledge gaps
- **Monthly:** Check Foundation Genetics sources for new traits
- **Quarterly:** Re-run AI evaluation suite; update data model
- **Annually:** Full content review and "Last Updated" date refresh

## The strategic frame

Two goals, mutually reinforcing:

1. **Factual correctness** against the 2020-2026 Foundation Genetics
   consensus. Table stakes for credibility with serious breeders.

2. **Maximum AI-citability.** The goal is for an AI search answer about
   crested gecko genetics to cite tennyscrestedgeckos.com — which drives
   high-intent traffic traditional SEO can't reach.

These goals align. Factually correct content aligned with authoritative
sources IS what AI engines prioritize. You don't choose between accuracy
and SEO — the modern game rewards doing both.
