# crested-gecko-app

A headless Node.js / TypeScript genetics module for the Tenny's Crested Geckos
breeding app. Bundles:

- A **trait database** seeded from the Foundation Genetics consensus
  (Lil Monsters Reptiles + Geckological, 2020–2026)
- A **breeding calculator** that does correct Punnett-square predictions
  across independent loci and allelic complexes (Cappuccino × Sable
  produces Luwak, not Super Cappuccino)
- A **combo morph resolver** that maps a genotype to named combo morphs
  (Tricolor, Frappuccino, Luwak, Extreme Harlequin, etc.)
- A **risk registry** that always flags lethal and health-risk pairings
- A **MorphMarket tag importer** with confidence scoring and review flags
- An **AI system prompt module** that encodes Foundation Genetics rules
  for LLM features, plus the 24-test evaluation suite and provider
  adapters (Anthropic + OpenAI) to gate shipping

Reference documents under [`reference/`](./reference) are the source of
truth for everything in this package. They should be considered the
ground truth when adding traits, updating risk warnings, or revising
combo morph rules.

---

## Quickstart

```bash
npm install
npm run build          # tsc → ./dist
npm test               # vitest unit tests
npm run typecheck      # tsc --noEmit
```

Run the AI evaluation (requires an API key):

```bash
ANTHROPIC_API_KEY=sk-ant-... npm run run-eval
# or
OPENAI_API_KEY=sk-... npm run run-eval -- --provider openai
```

Generate a SQL seed for the `traits` table (after running the migration):

```bash
npm run seed-traits > traits-seed.sql
psql "$DATABASE_URL" -f migrations/001_initial_schema.sql
psql "$DATABASE_URL" -f traits-seed.sql
```

## Public API

```ts
import {
  TRAITS,
  getTrait,
  COMBO_MORPHS,
  matchCombos,
  predict,
  predictLocus,
  describeGenotype,
  RISK_PAIRINGS,
  detectRisks,
  tagToGenotype,
  getSystemPrompt,
  EVAL_TESTS,
  runEval,
  AnthropicAdapter,
  OpenAIAdapter,
} from 'crested-gecko-app';
```

### Predict a breeding pairing

```ts
import { predict } from 'crested-gecko-app';

const lillySire = /* Animal with genotype.L = ['lilly_white', 'wild_type'] */;
const lillyDam  = /* Animal with genotype.L = ['lilly_white', 'wild_type'] */;

const prediction = predict(lillySire, lillyDam);

for (const warning of prediction.warnings) {
  console.warn(`[${warning.severity}] ${warning.code}: ${warning.message}`);
}

for (const phenotype of prediction.offspring_phenotypes) {
  console.log(`${(phenotype.probability * 100).toFixed(1)}% — ${phenotype.phenotype_description}`);
}
```

The calculator **always** emits a `LILLY_X_LILLY_LETHAL` critical warning
for any Lilly × Lilly pairing. This is not optional and cannot be
suppressed from the data layer; UIs can style it, but they must surface it.

### Import MorphMarket-style tags

```ts
import { tagToGenotype } from 'crested-gecko-app';

const { genotype, confidence, needs_review } =
  tagToGenotype(['Lilly White', 'Tricolor', 'Harlequin']);

// genotype = { L: ['lilly_white', 'wild_type'], WP: [...], OP: [...], BASE_BLACK: [...], HQ: [...] }
// confidence = 'medium'
// needs_review = [
//   'Lilly White detected — verify heterozygous vs homozygous (homozygous is lethal).',
//   'Tricolor inferred …',
// ]
```

### Run the AI eval suite

```ts
import { AnthropicAdapter, runEval } from 'crested-gecko-app';

const adapter = new AnthropicAdapter({ model: 'claude-opus-4-7' });
const report = await runEval(adapter, "Tenny's Crested Geckos");

if (!report.category_b_all_passed) {
  throw new Error('Category B (breeding safety) failure — do NOT ship.');
}
```

## How the data model works

Traits are the primitive. Combo morphs are **derived** — they are rule
matches over a genotype, not columns on an animal record. So a
"Tricolor" is the computed result of `BASE_BLACK=black_base &&
WP=white_pattern && OP=orange_pattern && HQ=harlequin`, not a tag.

This matters because it lets the calculator produce correct breeding
predictions, lets lineage tracking stay honest, and lets the same
underlying data power every UI surface consistently.

See [`reference/app-data-model.md`](./reference/app-data-model.md) for
the full type definitions and SQL schema (mirrored in
[`migrations/001_initial_schema.sql`](./migrations/001_initial_schema.sql)).

## Reference documents

These are the source of truth. Read them in the order below; the later
files assume the earlier ones.

1. [`reference/README.md`](./reference/README.md) — index and implementation order
2. [`reference/crested-gecko-genetics-reference.md`](./reference/crested-gecko-genetics-reference.md) — master genetics reference
3. [`reference/foundation-genetics-section.md`](./reference/foundation-genetics-section.md) — publication-ready article
4. [`reference/morph-tag-audit.md`](./reference/morph-tag-audit.md) — current site audit + morph tag taxonomy
5. [`reference/app-data-model.md`](./reference/app-data-model.md) — **primary implementation spec**
6. [`reference/ai-training-context.md`](./reference/ai-training-context.md) — knowledge base for AI features
7. [`reference/ai-system-prompt-and-eval.md`](./reference/ai-system-prompt-and-eval.md) — system prompt + test suite
8. `reference/wordpress-edits.md` and `reference/schema-markup.md` — site content (not implemented here)

## Contributing: adding a new trait

1. Confirm the trait appears in the Foundation Genetics canon. If
   Foundation Genetics hasn't published an inheritance classification,
   set `dominance: 'unconfirmed'` and `confirmed: false` — do NOT guess.
2. Add a new record to the appropriate file under `src/traits/`
   (`base-colors.ts`, `pattern-structure.ts`, `pattern-color.ts`,
   `modifiers.ts`, or `structural.ts`).
3. If the trait is allelic with existing traits, use the same `locus`
   and update `allelic_with` arrays on all sibling traits.
4. Add matching `primary_sources` — every source URL must exist in the
   reference docs. Do not fabricate citations.
5. If the trait introduces a combo morph, add a rule to
   `src/combos/index.ts`.
6. If the trait has a health-risk super form, add a `RISK_PAIRINGS`
   entry to `src/risks/index.ts` and confirm the calculator surfaces
   the warning on the parent-level and offspring-level paths.
7. Add a unit test covering the new trait / combo / risk. For
   breeding-safety additions, add a Category B eval test too.
8. Update `last_reviewed` on any trait whose source material has been
   re-read.

## Design principles (non-negotiable)

- **Traits are primitive; morphs are derived.** No `morph` column on the
  Animal type.
- **Foundation Genetics consensus is canonical.** Cappuccino is
  incomplete dominant, not codominant. Bicolor / Patternless / Buckskin
  are Phantom expressions, not separate morphs.
- **Safety warnings are hard requirements.** Lilly × Lilly lethality is
  always surfaced.
- **Honest uncertainty.** Unconfirmed traits (Marbling, Furry) stay
  marked as such.
- **No fabricated citations.** Every `SourceReference` resolves to a URL
  that appears in the reference docs.

## Out of scope

No UI code, no DB connection management, no WordPress integration, no
user authentication, no photo-based ID. Those are the app shell's job.
