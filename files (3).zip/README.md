# Kaleidoscope Integration — Handoff Bundle

This folder contains everything needed to hand off the Kaleidoscope Model integration to Claude Code.

## Files in this bundle

1. **`KALEIDOSCOPE_INTEGRATION.md`** — The main brief. Five workstreams, decision points, acceptance criteria, open questions for you. **Read this first.**

2. **`GENETICS_GUIDE_CONTENT.md`** — All 10 sections of educational content for the Genetics Guide page, ready to drop into Supabase records or render as markdown. Properly attributed, all quotes under 15 words.

3. **`KALEIDOSCOPE_MODULE_SPEC.md`** — Full TypeScript module specification for the inheritance math. Type definitions, file structure, pseudocode, test cases, and a worked example from the Kaleidoscope paper for verification.

## How to hand this off to Claude Code

### Option A: Start with the foundational workstream

Drop these three files into your repo at `docs/kaleidoscope/` and run this prompt in Claude Code:

> Read `docs/kaleidoscope/KALEIDOSCOPE_INTEGRATION.md` and the two referenced files in the same folder. This is a supplemental brief for adding the Kaleidoscope Model of Inheritance to Geck Inspect. The app already has a Genetics Calculator, a parked Genetics Guide page, a parked Morph Guide page (with a known RLS bug), and a headless "Foundation Genetics" TypeScript module. Do NOT duplicate or replace any existing functionality. Your job is to extend the system with Kaleidoscope as an additional layer.
> 
> Before doing any work, read the existing genetics module, the existing calculator, the existing Genetics Guide page (even though it's parked), and the geckos/clutches Supabase schemas. Then summarize for me: (a) what already exists, (b) what's planned in the brief, and (c) the gaps where the brief should adapt to the existing code rather than the other way around.
> 
> Do NOT write any code yet. Do NOT modify any files yet. Just produce that summary and ask me the open questions listed at the end of the brief. Once I answer, we'll start with Workstream 1 (the schema migration).

### Option B: If you want to start with the Genetics Guide page (lower risk)

> Read `docs/kaleidoscope/KALEIDOSCOPE_INTEGRATION.md` Workstream 2, then read `docs/kaleidoscope/GENETICS_GUIDE_CONTENT.md`. The Genetics Guide page is currently parked/disabled in PageConfig. Re-enable it, set up the routing, and populate it with the 10 sections of content from the GENETICS_GUIDE_CONTENT.md file.
> 
> Decision: should the content live as static markdown files in the repo, or as records in a `genetics_guide_section` Supabase table that admins can edit via UI? I'm leaning toward the Supabase approach because the Kaleidoscope authors have more content coming (Coverage and Structure deep-dive pages are listed as "coming soon" on their site), but I'd like your assessment based on the existing app architecture before you build it.

### Option C: If you want to skip ahead to the calculator

> Read `docs/kaleidoscope/KALEIDOSCOPE_MODULE_SPEC.md`. The existing Genetics Calculator handles Lilly White, axanthic, Cappuccino/Sable/Frappuccino, and polygenic patterning. We're adding Kaleidoscope as a parallel mode in the calculator, not replacing the existing logic.
> 
> First, examine the existing calculator code and the headless Foundation Genetics module. Then propose a directory structure for the new `kaleidoscope` module that fits cleanly alongside the existing one. Don't write any code yet, just the structure proposal and any naming-convention questions.

## What you (Tennyson) should do before handing off

1. **Verify the file paths and entity names** in `KALEIDOSCOPE_INTEGRATION.md` match your actual repo structure. Specifically:
   - The Supabase table for traits (referenced as the "genetic truth layer")
   - The headless Foundation Genetics module path
   - The PageConfig record name for the Genetics Guide page

2. **Decide the open questions** at the end of `KALEIDOSCOPE_INTEGRATION.md` either ahead of time or in your first Claude Code turn:
   - Separate `gecko_genotype` table or columns on `geckos`?
   - Markdown content vs. Supabase records for the Guide?
   - Tier gating structure for the genotype editor?
   - Extend the existing genetics module or create a parallel one?
   - Default calculator mode (Kaleidoscope or Classic)?

3. **Make sure your CONTEXT.md, INTENT.md, ARCHITECTURE.md, and DECISIONS.md files exist in the repo root.** Claude Code should reference them. If they don't exist or are out of date, this handoff will be less effective.

4. **Decide your starting workstream.** I'd recommend Workstream 2 (Genetics Guide content) before Workstream 1 (schema) because:
   - It's lower risk (just content, no schema changes).
   - It validates the Kaleidoscope framing before you commit to schema.
   - It produces visible user value immediately.
   - The Morph Guide RLS bug can be fixed in the same pass.

   But Workstream 1 is the dependency for everything else. So if you want to go fast, do them in parallel: Workstream 2 in one Claude Code session, Workstream 1 in another, then merge.

## What I'd watch for

- **The Phantom debate is unresolved.** If Claude Code starts treating one model as "correct" in the UI copy, push back. The app should be neutral.
- **The Foundation Genetics module is the source of truth for traits Kaleidoscope doesn't cover** (axanthic, Lilly White, Cappuccino series). Don't let Kaleidoscope code start handling those.
- **Don't paywall education.** The Genetics Guide should be free-tier visible. Only the prediction tools and bulk imports paywall.
- **Test the (2/2/0) edge case.** It's the falsifiability hook for the whole Kaleidoscope Model. If the calculator gets it wrong, the framework breaks.
- **Confidence levels matter.** Users will fill in genotypes from photos and lineage estimates. The UI must make it visible when a prediction is built on shaky inputs vs. confirmed data.

## Questions or revisions

If you want me to revise any of these documents (different acceptance criteria, different schema design, more or fewer guide sections, different tier gating), just say which file and what to change. I can also write out the specific Supabase migration SQL, the React component for the genotype editor, or the test cases for the inheritance module if you want any of them as runnable code rather than spec.
